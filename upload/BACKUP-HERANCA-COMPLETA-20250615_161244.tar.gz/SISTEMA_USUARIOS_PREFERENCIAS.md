# 👥 SISTEMA DE GESTÃO DE USUÁRIOS - JÉSSICA SANTOS ERP

## 🎯 FUNCIONALIDADES DE USUÁRIOS IMPLEMENTADAS

### 👤 GESTÃO COMPLETA DE USUÁRIOS
- **Criação de usuários** com diferentes perfis
- **Sistema de permissões** granular
- **Autenticação segura** com JWT
- **Perfis personalizados** por função
- **Histórico de atividades** de usuários
- **Configurações individuais** por usuário

## 🧩 COMPONENTES DE USUÁRIOS

### 👤 CONFIGURAÇÃO DE USUÁRIO ADMINISTRADOR
```jsx
// src/components/setup/UserSetup.jsx
import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { User, Shield, Eye, EyeOff, Upload } from 'lucide-react'
import { validateEmail, validatePassword } from '@/utils/validation'

const UserSetup = ({ data = {}, onComplete }) => {
  const [userData, setUserData] = useState({
    nome: 'Jéssica Santos',
    email: 'jessica@jessicasantos.com.br',
    senha: '',
    confirmarSenha: '',
    telefone: '(11) 99999-9999',
    cargo: 'Administradora',
    avatar: '',
    perfil: 'admin',
    ...data
  })

  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [errors, setErrors] = useState({})
  const [isValid, setIsValid] = useState(false)

  useEffect(() => {
    validateForm()
  }, [userData])

  const validateForm = () => {
    const newErrors = {}

    // Validar nome
    if (!userData.nome.trim()) {
      newErrors.nome = 'Nome é obrigatório'
    }

    // Validar email
    if (!userData.email.trim()) {
      newErrors.email = 'Email é obrigatório'
    } else if (!validateEmail(userData.email)) {
      newErrors.email = 'Email inválido'
    }

    // Validar senha
    if (!userData.senha) {
      newErrors.senha = 'Senha é obrigatória'
    } else {
      const passwordValidation = validatePassword(userData.senha)
      if (!passwordValidation.isValid) {
        newErrors.senha = passwordValidation.errors.join(', ')
      }
    }

    // Validar confirmação de senha
    if (userData.senha !== userData.confirmarSenha) {
      newErrors.confirmarSenha = 'Senhas não coincidem'
    }

    setErrors(newErrors)
    const valid = Object.keys(newErrors).length === 0
    setIsValid(valid)

    if (valid) {
      const { confirmarSenha, ...userDataToSave } = userData
      onComplete(userDataToSave)
    }
  }

  const handleChange = (field, value) => {
    setUserData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleAvatarUpload = (event) => {
    const file = event.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        handleChange('avatar', e.target.result)
      }
      reader.readAsDataURL(file)
    }
  }

  const getPasswordStrength = (password) => {
    if (!password) return { strength: 0, label: 'Muito fraca', color: 'bg-red-500' }
    
    let score = 0
    if (password.length >= 8) score++
    if (/[a-z]/.test(password)) score++
    if (/[A-Z]/.test(password)) score++
    if (/[0-9]/.test(password)) score++
    if (/[^A-Za-z0-9]/.test(password)) score++

    const levels = [
      { strength: 0, label: 'Muito fraca', color: 'bg-red-500' },
      { strength: 1, label: 'Fraca', color: 'bg-orange-500' },
      { strength: 2, label: 'Regular', color: 'bg-yellow-500' },
      { strength: 3, label: 'Boa', color: 'bg-blue-500' },
      { strength: 4, label: 'Forte', color: 'bg-green-500' },
      { strength: 5, label: 'Muito forte', color: 'bg-green-600' }
    ]

    return levels[score]
  }

  const passwordStrength = getPasswordStrength(userData.senha)

  return (
    <div className="space-y-6">
      <Alert>
        <Shield className="w-4 h-4" />
        <AlertDescription>
          Este será o usuário administrador principal do sistema. 
          Mantenha as credenciais seguras e use uma senha forte.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="w-5 h-5" />
            <span>Dados do Administrador</span>
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Avatar */}
          <div className="flex items-center space-x-4">
            <Avatar className="w-20 h-20">
              <AvatarImage src={userData.avatar} />
              <AvatarFallback className="text-lg">
                {userData.nome.split(' ').map(n => n[0]).join('').toUpperCase()}
              </AvatarFallback>
            </Avatar>
            
            <div>
              <Label htmlFor="avatar-upload" className="cursor-pointer">
                <Button variant="outline" asChild>
                  <span>
                    <Upload className="w-4 h-4 mr-2" />
                    Escolher Foto
                  </span>
                </Button>
              </Label>
              <input
                id="avatar-upload"
                type="file"
                accept="image/*"
                onChange={handleAvatarUpload}
                className="hidden"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Recomendado: 400x400px, máximo 2MB
              </p>
            </div>
          </div>

          {/* Informações Básicas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="nome">Nome Completo *</Label>
              <Input
                id="nome"
                value={userData.nome}
                onChange={(e) => handleChange('nome', e.target.value)}
                placeholder="Jéssica Santos"
                className={errors.nome ? 'border-red-500' : ''}
              />
              {errors.nome && (
                <p className="text-sm text-red-500 mt-1">{errors.nome}</p>
              )}
            </div>

            <div>
              <Label htmlFor="cargo">Cargo</Label>
              <Input
                id="cargo"
                value={userData.cargo}
                onChange={(e) => handleChange('cargo', e.target.value)}
                placeholder="Administradora"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={userData.email}
                onChange={(e) => handleChange('email', e.target.value)}
                placeholder="jessica@jessicasantos.com.br"
                className={errors.email ? 'border-red-500' : ''}
              />
              {errors.email && (
                <p className="text-sm text-red-500 mt-1">{errors.email}</p>
              )}
            </div>

            <div>
              <Label htmlFor="telefone">Telefone</Label>
              <Input
                id="telefone"
                value={userData.telefone}
                onChange={(e) => handleChange('telefone', e.target.value)}
                placeholder="(11) 99999-9999"
              />
            </div>
          </div>

          {/* Senha */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="senha">Senha *</Label>
              <div className="relative">
                <Input
                  id="senha"
                  type={showPassword ? 'text' : 'password'}
                  value={userData.senha}
                  onChange={(e) => handleChange('senha', e.target.value)}
                  placeholder="Senha forte"
                  className={errors.senha ? 'border-red-500' : ''}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>
              
              {userData.senha && (
                <div className="mt-2">
                  <div className="flex items-center space-x-2">
                    <div className="flex-1 bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full transition-all ${passwordStrength.color}`}
                        style={{ width: `${(passwordStrength.strength / 5) * 100}%` }}
                      />
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {passwordStrength.label}
                    </span>
                  </div>
                </div>
              )}
              
              {errors.senha && (
                <p className="text-sm text-red-500 mt-1">{errors.senha}</p>
              )}
            </div>

            <div>
              <Label htmlFor="confirmar-senha">Confirmar Senha *</Label>
              <div className="relative">
                <Input
                  id="confirmar-senha"
                  type={showConfirmPassword ? 'text' : 'password'}
                  value={userData.confirmarSenha}
                  onChange={(e) => handleChange('confirmarSenha', e.target.value)}
                  placeholder="Confirme a senha"
                  className={errors.confirmarSenha ? 'border-red-500' : ''}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>
              {errors.confirmarSenha && (
                <p className="text-sm text-red-500 mt-1">{errors.confirmarSenha}</p>
              )}
            </div>
          </div>

          {/* Perfil */}
          <div>
            <Label>Perfil de Acesso</Label>
            <div className="mt-2">
              <Badge variant="default" className="bg-purple-500">
                <Shield className="w-3 h-3 mr-1" />
                Administrador Total
              </Badge>
              <p className="text-sm text-muted-foreground mt-1">
                Acesso completo a todas as funcionalidades do sistema
              </p>
            </div>
          </div>

          {/* Requisitos de Senha */}
          <Alert>
            <Shield className="w-4 h-4" />
            <AlertDescription>
              <strong>Requisitos da senha:</strong>
              <ul className="list-disc list-inside mt-1 text-sm">
                <li>Mínimo 8 caracteres</li>
                <li>Pelo menos uma letra minúscula</li>
                <li>Pelo menos uma letra maiúscula</li>
                <li>Pelo menos um número</li>
                <li>Pelo menos um caractere especial</li>
              </ul>
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Status */}
      <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
        <span className="text-sm">
          {isValid ? '✅ Usuário administrador configurado' : '⚠️ Complete os campos obrigatórios'}
        </span>
        {isValid && (
          <Badge variant="default">Etapa Concluída</Badge>
        )}
      </div>
    </div>
  )
}

export default UserSetup
```

### 🎨 CONFIGURAÇÃO DE PREFERÊNCIAS
```jsx
// src/components/setup/PreferencesSetup.jsx
import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Palette, 
  Bell, 
  Globe, 
  Shield, 
  Monitor,
  Moon,
  Sun,
  Volume2,
  Mail,
  MessageCircle
} from 'lucide-react'

const PreferencesSetup = ({ data = {}, onComplete }) => {
  const [preferences, setPreferences] = useState({
    appearance: {
      theme: 'light',
      primaryColor: 'purple',
      fontSize: 'medium',
      compactMode: false,
      animations: true,
      ...data.appearance
    },
    notifications: {
      email: true,
      whatsapp: true,
      push: true,
      sound: true,
      volume: 50,
      agendamentos: true,
      pagamentos: true,
      lembretes: true,
      marketing: false,
      ...data.notifications
    },
    system: {
      language: 'pt-BR',
      timezone: 'America/Sao_Paulo',
      dateFormat: 'DD/MM/YYYY',
      timeFormat: '24h',
      currency: 'BRL',
      autoSave: true,
      autoBackup: true,
      ...data.system
    },
    privacy: {
      analytics: true,
      cookies: true,
      dataSharing: false,
      publicProfile: true,
      ...data.privacy
    },
    ...data
  })

  useEffect(() => {
    onComplete(preferences)
  }, [preferences, onComplete])

  const handleChange = (category, field, value) => {
    setPreferences(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [field]: value
      }
    }))
  }

  const themes = [
    { value: 'light', label: 'Claro', icon: Sun },
    { value: 'dark', label: 'Escuro', icon: Moon },
    { value: 'auto', label: 'Automático', icon: Monitor }
  ]

  const colors = [
    { value: 'purple', label: 'Roxo', color: 'bg-purple-500' },
    { value: 'pink', label: 'Rosa', color: 'bg-pink-500' },
    { value: 'blue', label: 'Azul', color: 'bg-blue-500' },
    { value: 'green', label: 'Verde', color: 'bg-green-500' },
    { value: 'orange', label: 'Laranja', color: 'bg-orange-500' }
  ]

  const fontSizes = [
    { value: 'small', label: 'Pequeno' },
    { value: 'medium', label: 'Médio' },
    { value: 'large', label: 'Grande' }
  ]

  return (
    <div className="space-y-6">
      <Tabs defaultValue="appearance" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="appearance" className="flex items-center space-x-2">
            <Palette className="w-4 h-4" />
            <span>Aparência</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center space-x-2">
            <Bell className="w-4 h-4" />
            <span>Notificações</span>
          </TabsTrigger>
          <TabsTrigger value="system" className="flex items-center space-x-2">
            <Globe className="w-4 h-4" />
            <span>Sistema</span>
          </TabsTrigger>
          <TabsTrigger value="privacy" className="flex items-center space-x-2">
            <Shield className="w-4 h-4" />
            <span>Privacidade</span>
          </TabsTrigger>
        </TabsList>

        {/* Aparência */}
        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Palette className="w-5 h-5" />
                <span>Configurações de Aparência</span>
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Tema */}
              <div>
                <Label className="text-base font-medium">Tema</Label>
                <div className="grid grid-cols-3 gap-3 mt-2">
                  {themes.map(theme => {
                    const Icon = theme.icon
                    return (
                      <div
                        key={theme.value}
                        className={`p-4 border rounded-lg cursor-pointer transition-all ${
                          preferences.appearance.theme === theme.value
                            ? 'border-primary bg-primary/5'
                            : 'border-muted hover:border-primary/50'
                        }`}
                        onClick={() => handleChange('appearance', 'theme', theme.value)}
                      >
                        <Icon className="w-6 h-6 mx-auto mb-2" />
                        <p className="text-sm text-center">{theme.label}</p>
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* Cor Principal */}
              <div>
                <Label className="text-base font-medium">Cor Principal</Label>
                <div className="flex space-x-3 mt-2">
                  {colors.map(color => (
                    <div
                      key={color.value}
                      className={`w-12 h-12 rounded-full cursor-pointer border-4 transition-all ${color.color} ${
                        preferences.appearance.primaryColor === color.value
                          ? 'border-gray-800 scale-110'
                          : 'border-gray-300 hover:scale-105'
                      }`}
                      onClick={() => handleChange('appearance', 'primaryColor', color.value)}
                      title={color.label}
                    />
                  ))}
                </div>
              </div>

              {/* Tamanho da Fonte */}
              <div>
                <Label className="text-base font-medium">Tamanho da Fonte</Label>
                <Select
                  value={preferences.appearance.fontSize}
                  onValueChange={(value) => handleChange('appearance', 'fontSize', value)}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {fontSizes.map(size => (
                      <SelectItem key={size.value} value={size.value}>
                        {size.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Opções Adicionais */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Modo Compacto</Label>
                    <p className="text-sm text-muted-foreground">
                      Interface mais densa com menos espaçamento
                    </p>
                  </div>
                  <Switch
                    checked={preferences.appearance.compactMode}
                    onCheckedChange={(checked) => handleChange('appearance', 'compactMode', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Animações</Label>
                    <p className="text-sm text-muted-foreground">
                      Efeitos de transição e animações
                    </p>
                  </div>
                  <Switch
                    checked={preferences.appearance.animations}
                    onCheckedChange={(checked) => handleChange('appearance', 'animations', checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notificações */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Bell className="w-5 h-5" />
                <span>Configurações de Notificações</span>
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Canais de Notificação */}
              <div>
                <Label className="text-base font-medium mb-4 block">Canais de Notificação</Label>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Mail className="w-5 h-5" />
                      <div>
                        <Label>Email</Label>
                        <p className="text-sm text-muted-foreground">
                          Receber notificações por email
                        </p>
                      </div>
                    </div>
                    <Switch
                      checked={preferences.notifications.email}
                      onCheckedChange={(checked) => handleChange('notifications', 'email', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <MessageCircle className="w-5 h-5" />
                      <div>
                        <Label>WhatsApp</Label>
                        <p className="text-sm text-muted-foreground">
                          Receber notificações via WhatsApp
                        </p>
                      </div>
                    </div>
                    <Switch
                      checked={preferences.notifications.whatsapp}
                      onCheckedChange={(checked) => handleChange('notifications', 'whatsapp', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Bell className="w-5 h-5" />
                      <div>
                        <Label>Push</Label>
                        <p className="text-sm text-muted-foreground">
                          Notificações push no navegador
                        </p>
                      </div>
                    </div>
                    <Switch
                      checked={preferences.notifications.push}
                      onCheckedChange={(checked) => handleChange('notifications', 'push', checked)}
                    />
                  </div>
                </div>
              </div>

              {/* Som */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <Volume2 className="w-5 h-5" />
                    <Label className="text-base font-medium">Som das Notificações</Label>
                  </div>
                  <Switch
                    checked={preferences.notifications.sound}
                    onCheckedChange={(checked) => handleChange('notifications', 'sound', checked)}
                  />
                </div>
                
                {preferences.notifications.sound && (
                  <div>
                    <Label className="text-sm">Volume: {preferences.notifications.volume}%</Label>
                    <Slider
                      value={[preferences.notifications.volume]}
                      onValueChange={([value]) => handleChange('notifications', 'volume', value)}
                      max={100}
                      step={10}
                      className="mt-2"
                    />
                  </div>
                )}
              </div>

              {/* Tipos de Notificação */}
              <div>
                <Label className="text-base font-medium mb-4 block">Tipos de Notificação</Label>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Agendamentos</Label>
                      <p className="text-sm text-muted-foreground">
                        Novos agendamentos e alterações
                      </p>
                    </div>
                    <Switch
                      checked={preferences.notifications.agendamentos}
                      onCheckedChange={(checked) => handleChange('notifications', 'agendamentos', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Pagamentos</Label>
                      <p className="text-sm text-muted-foreground">
                        Confirmações e pendências de pagamento
                      </p>
                    </div>
                    <Switch
                      checked={preferences.notifications.pagamentos}
                      onCheckedChange={(checked) => handleChange('notifications', 'pagamentos', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Lembretes</Label>
                      <p className="text-sm text-muted-foreground">
                        Lembretes de ensaios e tarefas
                      </p>
                    </div>
                    <Switch
                      checked={preferences.notifications.lembretes}
                      onCheckedChange={(checked) => handleChange('notifications', 'lembretes', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Marketing</Label>
                      <p className="text-sm text-muted-foreground">
                        Dicas e novidades do sistema
                      </p>
                    </div>
                    <Switch
                      checked={preferences.notifications.marketing}
                      onCheckedChange={(checked) => handleChange('notifications', 'marketing', checked)}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Sistema */}
        <TabsContent value="system">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Globe className="w-5 h-5" />
                <span>Configurações do Sistema</span>
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-base font-medium">Idioma</Label>
                  <Select
                    value={preferences.system.language}
                    onValueChange={(value) => handleChange('system', 'language', value)}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pt-BR">Português (Brasil)</SelectItem>
                      <SelectItem value="en-US">English (US)</SelectItem>
                      <SelectItem value="es-ES">Español</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-base font-medium">Fuso Horário</Label>
                  <Select
                    value={preferences.system.timezone}
                    onValueChange={(value) => handleChange('system', 'timezone', value)}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="America/Sao_Paulo">São Paulo (GMT-3)</SelectItem>
                      <SelectItem value="America/New_York">New York (GMT-5)</SelectItem>
                      <SelectItem value="Europe/London">London (GMT+0)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-base font-medium">Formato de Data</Label>
                  <Select
                    value={preferences.system.dateFormat}
                    onValueChange={(value) => handleChange('system', 'dateFormat', value)}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="DD/MM/YYYY">DD/MM/AAAA</SelectItem>
                      <SelectItem value="MM/DD/YYYY">MM/DD/AAAA</SelectItem>
                      <SelectItem value="YYYY-MM-DD">AAAA-MM-DD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-base font-medium">Formato de Hora</Label>
                  <Select
                    value={preferences.system.timeFormat}
                    onValueChange={(value) => handleChange('system', 'timeFormat', value)}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="24h">24 horas</SelectItem>
                      <SelectItem value="12h">12 horas (AM/PM)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Opções Automáticas */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Salvamento Automático</Label>
                    <p className="text-sm text-muted-foreground">
                      Salvar alterações automaticamente
                    </p>
                  </div>
                  <Switch
                    checked={preferences.system.autoSave}
                    onCheckedChange={(checked) => handleChange('system', 'autoSave', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Backup Automático</Label>
                    <p className="text-sm text-muted-foreground">
                      Criar backups automáticos dos dados
                    </p>
                  </div>
                  <Switch
                    checked={preferences.system.autoBackup}
                    onCheckedChange={(checked) => handleChange('system', 'autoBackup', checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Privacidade */}
        <TabsContent value="privacy">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="w-5 h-5" />
                <span>Configurações de Privacidade</span>
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Analytics</Label>
                    <p className="text-sm text-muted-foreground">
                      Permitir coleta de dados para melhorar o sistema
                    </p>
                  </div>
                  <Switch
                    checked={preferences.privacy.analytics}
                    onCheckedChange={(checked) => handleChange('privacy', 'analytics', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Cookies</Label>
                    <p className="text-sm text-muted-foreground">
                      Aceitar cookies para melhor experiência
                    </p>
                  </div>
                  <Switch
                    checked={preferences.privacy.cookies}
                    onCheckedChange={(checked) => handleChange('privacy', 'cookies', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Compartilhamento de Dados</Label>
                    <p className="text-sm text-muted-foreground">
                      Compartilhar dados com parceiros (sempre anônimos)
                    </p>
                  </div>
                  <Switch
                    checked={preferences.privacy.dataSharing}
                    onCheckedChange={(checked) => handleChange('privacy', 'dataSharing', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Perfil Público</Label>
                    <p className="text-sm text-muted-foreground">
                      Permitir que outros vejam seu perfil público
                    </p>
                  </div>
                  <Switch
                    checked={preferences.privacy.publicProfile}
                    onCheckedChange={(checked) => handleChange('privacy', 'publicProfile', checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Status */}
      <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
        <span className="text-sm">
          ✅ Preferências configuradas com sucesso
        </span>
        <Badge variant="default">Etapa Concluída</Badge>
      </div>
    </div>
  )
}

export default PreferencesSetup
```

---

**💾 RESULTADO:** Sistema completo de gestão de usuários e preferências com interface visual!

