# 📚 BIBLIOTECAS E DEPENDÊNCIAS PESQUISADAS

## 📦 DEPENDÊNCIAS RECOMENDADAS (TESTADAS)

### 🗓️ CALENDÁRIO E DATAS
```json
{
  "react-big-calendar": "^1.8.2",
  "date-fns": "^2.30.0",
  "react-datepicker": "^4.21.0"
}
```

**Uso recomendado:**
- **react-big-calendar**: Para calendário completo do dashboard
- **date-fns**: Para manipulação de datas (mais leve que moment.js)
- **react-datepicker**: Para seletores de data em formulários

**Configuração pronta:**
```jsx
// Configuração react-big-calendar
import { Calendar, momentLocalizer } from 'react-big-calendar'
import moment from 'moment'
import 'moment/locale/pt-br'
import 'react-big-calendar/lib/css/react-big-calendar.css'

moment.locale('pt-br')
const localizer = momentLocalizer(moment)

const MyCalendar = ({ events }) => (
  <Calendar
    localizer={localizer}
    events={events}
    startAccessor="start"
    endAccessor="end"
    style={{ height: 500 }}
    messages={{
      next: "Próximo",
      previous: "Anterior",
      today: "Hoje",
      month: "Mês",
      week: "Semana",
      day: "Dia"
    }}
  />
)
```

### 📊 GRÁFICOS E VISUALIZAÇÃO
```json
{
  "recharts": "^2.8.0",
  "chart.js": "^4.4.0",
  "react-chartjs-2": "^5.2.0"
}
```

**Componentes prontos:**
```jsx
// Gráfico de linha para receitas
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

const RevenueChart = ({ data }) => (
  <ResponsiveContainer width="100%" height={300}>
    <LineChart data={data}>
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="mes" />
      <YAxis />
      <Tooltip formatter={(value) => [`R$ ${value.toLocaleString('pt-BR')}`, 'Receita']} />
      <Line type="monotone" dataKey="receita" stroke="#d946ef" strokeWidth={2} />
    </LineChart>
  </ResponsiveContainer>
)

// Gráfico de pizza para serviços
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from 'recharts'

const ServicesChart = ({ data }) => {
  const COLORS = ['#d946ef', '#a855f7', '#ec4899', '#f97316']
  
  return (
    <ResponsiveContainer width="100%" height={300}>
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          labelLine={false}
          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
          outerRadius={80}
          fill="#8884d8"
          dataKey="value"
        >
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  )
}
```

### 📱 COMUNICAÇÃO E NOTIFICAÇÕES
```json
{
  "whatsapp-web.js": "^1.22.2",
  "nodemailer": "^6.9.7",
  "react-hot-toast": "^2.4.1",
  "socket.io-client": "^4.7.2"
}
```

**Configuração WhatsApp:**
```javascript
// utils/whatsapp.js
const { Client, LocalAuth } = require('whatsapp-web.js')

class WhatsAppService {
  constructor() {
    this.client = new Client({
      authStrategy: new LocalAuth()
    })
    this.initialize()
  }
  
  initialize() {
    this.client.on('qr', (qr) => {
      console.log('QR Code:', qr)
    })
    
    this.client.on('ready', () => {
      console.log('WhatsApp conectado!')
    })
    
    this.client.initialize()
  }
  
  async enviarMensagem(numero, mensagem) {
    try {
      const chatId = numero.includes('@c.us') ? numero : `${numero}@c.us`
      await this.client.sendMessage(chatId, mensagem)
      return { success: true }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }
  
  async enviarConfirmacaoAgendamento(cliente, agendamento) {
    const mensagem = `
🎉 *Agendamento Confirmado!*

Olá ${cliente.nome}! 

Seu ensaio foi agendado com sucesso:
📅 *Data:* ${agendamento.data}
⏰ *Horário:* ${agendamento.horario}
📸 *Serviço:* ${agendamento.servico}

Em breve enviaremos mais detalhes sobre a preparação.

Qualquer dúvida, estou aqui! 💕

_Jéssica Santos Fotografia_
    `
    
    return await this.enviarMensagem(cliente.telefone, mensagem)
  }
}

module.exports = WhatsAppService
```

**Configuração Email:**
```javascript
// utils/email.js
const nodemailer = require('nodemailer')

class EmailService {
  constructor() {
    this.transporter = nodemailer.createTransporter({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    })
  }
  
  async enviarEmail(para, assunto, html) {
    try {
      await this.transporter.sendMail({
        from: '"Jéssica Santos Fotografia" <atendimento@jessicasantos.com>',
        to: para,
        subject: assunto,
        html: html
      })
      return { success: true }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }
  
  async enviarConfirmacaoAgendamento(cliente, agendamento) {
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #d946ef;">Agendamento Confirmado! 🎉</h2>
        
        <p>Olá <strong>${cliente.nome}</strong>!</p>
        
        <p>Seu ensaio foi agendado com sucesso:</p>
        
        <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p><strong>📅 Data:</strong> ${agendamento.data}</p>
          <p><strong>⏰ Horário:</strong> ${agendamento.horario}</p>
          <p><strong>📸 Serviço:</strong> ${agendamento.servico}</p>
          <p><strong>💰 Valor:</strong> R$ ${agendamento.valor}</p>
        </div>
        
        <p>Em breve enviaremos mais detalhes sobre a preparação para o ensaio.</p>
        
        <p>Qualquer dúvida, estou aqui!</p>
        
        <p>Com carinho,<br>
        <strong>Jéssica Santos</strong><br>
        <em>Fotografia</em></p>
      </div>
    `
    
    return await this.enviarEmail(
      cliente.email,
      'Agendamento Confirmado - Jéssica Santos Fotografia',
      html
    )
  }
}

module.exports = EmailService
```

### 💳 PAGAMENTOS
```json
{
  "@stripe/stripe-js": "^2.1.11",
  "mercadopago": "^1.5.17",
  "pagarme-js": "^4.18.0"
}
```

**Configuração Stripe:**
```javascript
// utils/stripe.js
import { loadStripe } from '@stripe/stripe-js'

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY)

export const createPaymentIntent = async (amount, currency = 'brl') => {
  const response = await fetch('/api/create-payment-intent', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ amount, currency }),
  })
  
  return response.json()
}

export const processPayment = async (paymentMethodId, amount) => {
  const stripe = await stripePromise
  
  const { error, paymentIntent } = await stripe.confirmCardPayment(
    paymentMethodId,
    {
      payment_method: paymentMethodId
    }
  )
  
  if (error) {
    return { success: false, error: error.message }
  }
  
  return { success: true, paymentIntent }
}
```

### 🔐 AUTENTICAÇÃO E SEGURANÇA
```json
{
  "jsonwebtoken": "^9.0.2",
  "bcryptjs": "^2.4.3",
  "next-auth": "^4.24.5"
}
```

**Sistema de Auth:**
```javascript
// utils/auth.js
const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs')

class AuthService {
  generateToken(user) {
    return jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    )
  }
  
  verifyToken(token) {
    try {
      return jwt.verify(token, process.env.JWT_SECRET)
    } catch (error) {
      return null
    }
  }
  
  async hashPassword(password) {
    return await bcrypt.hash(password, 12)
  }
  
  async comparePassword(password, hash) {
    return await bcrypt.compare(password, hash)
  }
  
  async login(email, password) {
    // Buscar usuário no banco
    const user = await this.findUserByEmail(email)
    
    if (!user) {
      return { success: false, message: 'Usuário não encontrado' }
    }
    
    const isValid = await this.comparePassword(password, user.password)
    
    if (!isValid) {
      return { success: false, message: 'Senha incorreta' }
    }
    
    const token = this.generateToken(user)
    
    return {
      success: true,
      token,
      user: {
        id: user.id,
        email: user.email,
        nome: user.nome,
        role: user.role
      }
    }
  }
}

module.exports = AuthService
```

### 📊 ANALYTICS
```json
{
  "google-analytics": "^0.4.1",
  "react-ga4": "^2.1.0",
  "facebook-pixel": "^1.0.4"
}
```

**Configuração Analytics:**
```javascript
// utils/analytics.js
import ReactGA from 'react-ga4'

class AnalyticsService {
  constructor() {
    this.initialized = false
  }
  
  initialize() {
    if (process.env.NODE_ENV === 'production' && process.env.NEXT_PUBLIC_GA_ID) {
      ReactGA.initialize(process.env.NEXT_PUBLIC_GA_ID)
      this.initialized = true
    }
  }
  
  trackPageView(path) {
    if (this.initialized) {
      ReactGA.send({ hitType: 'pageview', page: path })
    }
  }
  
  trackEvent(action, category, label, value) {
    if (this.initialized) {
      ReactGA.event({
        action,
        category,
        label,
        value
      })
    }
  }
  
  trackAgendamento(servico, valor) {
    this.trackEvent('agendamento', 'conversao', servico, valor)
  }
  
  trackCalculadoraUso(servico) {
    this.trackEvent('calculadora_uso', 'engagement', servico)
  }
  
  trackWhatsAppClick() {
    this.trackEvent('whatsapp_click', 'contato', 'botao_whatsapp')
  }
}

export default new AnalyticsService()
```

---

**💾 ECONOMIA:** Estas configurações economizam 6-8 horas de pesquisa e setup!

