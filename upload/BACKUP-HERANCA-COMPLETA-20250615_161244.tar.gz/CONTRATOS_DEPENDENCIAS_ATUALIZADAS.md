# 🔄 ATUALIZAÇÃO: DEPENDÊNCIAS DE CONTRATOS

## 📦 DEPENDÊNCIAS ADICIONAIS PARA CONTRATOS

### 📄 Geração de PDF
```json
{
  "jspdf": "^2.5.1",
  "jspdf-autotable": "^3.6.0",
  "html2canvas": "^1.4.1"
}
```

### ✍️ Assinatura Digital
```json
{
  "signature_pad": "^4.1.7",
  "react-signature-canvas": "^1.0.6"
}
```

### 📝 Editor de Texto Rico
```json
{
  "@tiptap/react": "^2.1.13",
  "@tiptap/starter-kit": "^2.1.13",
  "@tiptap/extension-document": "^2.1.13"
}
```

### 📊 Validação de Documentos
```json
{
  "cpf-cnpj-validator": "^1.0.3",
  "validator": "^13.11.0"
}
```

## 🔧 CONFIGURAÇÕES ATUALIZADAS

### 📄 Package.json Atualizado
```json
{
  "dependencies": {
    // ... dependências existentes ...
    "jspdf": "^2.5.1",
    "jspdf-autotable": "^3.6.0",
    "html2canvas": "^1.4.1",
    "signature_pad": "^4.1.7",
    "react-signature-canvas": "^1.0.6",
    "@tiptap/react": "^2.1.13",
    "@tiptap/starter-kit": "^2.1.13",
    "@tiptap/extension-document": "^2.1.13",
    "cpf-cnpj-validator": "^1.0.3",
    "validator": "^13.11.0"
  }
}
```

## 🧩 COMPONENTE DE ASSINATURA DIGITAL

### ✍️ Assinatura Canvas
```jsx
// src/components/contracts/SignaturePad.jsx
import React, { useRef, useState } from 'react'
import SignatureCanvas from 'react-signature-canvas'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { PenTool, RotateCcw, Check } from 'lucide-react'

const SignaturePad = ({ onSignature, clienteName }) => {
  const sigCanvas = useRef()
  const [isEmpty, setIsEmpty] = useState(true)

  const clear = () => {
    sigCanvas.current.clear()
    setIsEmpty(true)
  }

  const save = () => {
    if (!isEmpty) {
      const signature = sigCanvas.current.toDataURL()
      onSignature(signature)
    }
  }

  const handleEnd = () => {
    setIsEmpty(sigCanvas.current.isEmpty())
  }

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <PenTool className="w-5 h-5" />
          <span>Assinatura Digital</span>
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          {clienteName}, assine no campo abaixo para confirmar o contrato
        </p>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="border-2 border-dashed border-muted rounded-lg p-4">
          <SignatureCanvas
            ref={sigCanvas}
            canvasProps={{
              width: 500,
              height: 200,
              className: 'signature-canvas w-full h-48 border rounded'
            }}
            onEnd={handleEnd}
          />
        </div>
        
        <div className="flex justify-between">
          <Button variant="outline" onClick={clear} disabled={isEmpty}>
            <RotateCcw className="w-4 h-4 mr-2" />
            Limpar
          </Button>
          
          <Button onClick={save} disabled={isEmpty}>
            <Check className="w-4 h-4 mr-2" />
            Confirmar Assinatura
          </Button>
        </div>
        
        <p className="text-xs text-muted-foreground text-center">
          Ao assinar, você concorda com todos os termos e condições do contrato
        </p>
      </CardContent>
    </Card>
  )
}

export default SignaturePad
```

## 📝 EDITOR DE CONTRATOS

### 📄 Editor Rico
```jsx
// src/components/contracts/ContractEditor.jsx
import React from 'react'
import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Bold, Italic, List, ListOrdered, Undo, Redo } from 'lucide-react'

const ContractEditor = ({ content, onChange, readOnly = false }) => {
  const editor = useEditor({
    extensions: [StarterKit],
    content: content,
    editable: !readOnly,
    onUpdate: ({ editor }) => {
      onChange(editor.getHTML())
    }
  })

  if (!editor) return null

  return (
    <Card>
      <CardHeader>
        <CardTitle>Editor de Contrato</CardTitle>
        {!readOnly && (
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => editor.chain().focus().toggleBold().run()}
              className={editor.isActive('bold') ? 'bg-accent' : ''}
            >
              <Bold className="w-4 h-4" />
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => editor.chain().focus().toggleItalic().run()}
              className={editor.isActive('italic') ? 'bg-accent' : ''}
            >
              <Italic className="w-4 h-4" />
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => editor.chain().focus().toggleBulletList().run()}
              className={editor.isActive('bulletList') ? 'bg-accent' : ''}
            >
              <List className="w-4 h-4" />
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => editor.chain().focus().toggleOrderedList().run()}
              className={editor.isActive('orderedList') ? 'bg-accent' : ''}
            >
              <ListOrdered className="w-4 h-4" />
            </Button>
            
            <div className="border-l mx-2" />
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => editor.chain().focus().undo().run()}
              disabled={!editor.can().undo()}
            >
              <Undo className="w-4 h-4" />
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => editor.chain().focus().redo().run()}
              disabled={!editor.can().redo()}
            >
              <Redo className="w-4 h-4" />
            </Button>
          </div>
        )}
      </CardHeader>
      
      <CardContent>
        <EditorContent 
          editor={editor} 
          className="min-h-[400px] prose prose-sm max-w-none p-4 border rounded-md"
        />
      </CardContent>
    </Card>
  )
}

export default ContractEditor
```

## 🔧 UTILITÁRIOS ATUALIZADOS

### 📄 Validação de Documentos
```javascript
// src/utils/documentValidation.js
import { cpf, cnpj } from 'cpf-cnpj-validator'
import validator from 'validator'

export const validateCPF = (cpfNumber) => {
  return cpf.isValid(cpfNumber)
}

export const validateCNPJ = (cnpjNumber) => {
  return cnpj.isValid(cnpjNumber)
}

export const validateEmail = (email) => {
  return validator.isEmail(email)
}

export const validatePhone = (phone) => {
  const cleanPhone = phone.replace(/\D/g, '')
  return cleanPhone.length >= 10 && cleanPhone.length <= 11
}

export const formatCPF = (cpfNumber) => {
  return cpf.format(cpfNumber)
}

export const formatCNPJ = (cnpjNumber) => {
  return cnpj.format(cnpjNumber)
}

export const validateContractData = (data) => {
  const errors = []
  
  // Validações obrigatórias
  if (!data.cliente?.nome) errors.push('Nome do cliente é obrigatório')
  if (!data.cliente?.email || !validateEmail(data.cliente.email)) {
    errors.push('Email válido é obrigatório')
  }
  if (!data.cliente?.telefone || !validatePhone(data.cliente.telefone)) {
    errors.push('Telefone válido é obrigatório')
  }
  
  // Validar CPF ou CNPJ
  if (data.cliente?.cpf && !validateCPF(data.cliente.cpf)) {
    errors.push('CPF inválido')
  }
  if (data.cliente?.cnpj && !validateCNPJ(data.cliente.cnpj)) {
    errors.push('CNPJ inválido')
  }
  if (!data.cliente?.cpf && !data.cliente?.cnpj) {
    errors.push('CPF ou CNPJ é obrigatório')
  }
  
  // Validações financeiras
  if (!data.valor || data.valor <= 0) {
    errors.push('Valor deve ser maior que zero')
  }
  if (data.sinal && data.sinal > data.valor) {
    errors.push('Sinal não pode ser maior que o valor total')
  }
  
  // Validações de data
  if (data.dataVencimento) {
    const vencimento = new Date(data.dataVencimento)
    const hoje = new Date()
    if (vencimento <= hoje) {
      errors.push('Data de vencimento deve ser futura')
    }
  }
  
  return {
    isValid: errors.length === 0,
    errors
  }
}
```

## 📊 SERVIÇO DE CONTRATOS ATUALIZADO

### 🔧 Serviço Completo
```javascript
// src/services/contractService.js
import { generateContractPDF, validateContractData } from '@/utils/contractUtils'
import { emailService } from './index'

export class ContractService {
  constructor() {
    this.storageKey = 'jessica_erp_contratos'
  }

  async criarContrato(dadosContrato) {
    // Validar dados
    const validation = validateContractData(dadosContrato)
    if (!validation.isValid) {
      throw new Error(validation.errors.join(', '))
    }

    // Gerar PDF
    const pdfBlob = await generateContractPDF(dadosContrato)
    
    // Criar contrato
    const contrato = {
      id: `CONT-${Date.now()}`,
      ...dadosContrato,
      arquivo: pdfBlob,
      status: 'gerado',
      dataGeracao: new Date().toISOString(),
      dataAtualizacao: new Date().toISOString(),
      historico: [{
        acao: 'criado',
        data: new Date().toISOString(),
        usuario: 'sistema'
      }]
    }

    // Salvar
    this.salvarContrato(contrato)
    
    return contrato
  }

  async enviarContrato(contratoId, email) {
    const contrato = this.buscarContrato(contratoId)
    if (!contrato) throw new Error('Contrato não encontrado')

    // Enviar por email
    const resultado = await emailService.enviarContrato(contrato, email)
    
    if (resultado.success) {
      // Atualizar status
      this.atualizarStatus(contratoId, 'enviado', 'Enviado por email')
    }
    
    return resultado
  }

  assinarContrato(contratoId, assinatura, dadosAssinante) {
    const contrato = this.buscarContrato(contratoId)
    if (!contrato) throw new Error('Contrato não encontrado')

    const contratoAssinado = {
      ...contrato,
      assinatura: {
        imagem: assinatura,
        data: new Date().toISOString(),
        ip: dadosAssinante.ip,
        userAgent: dadosAssinante.userAgent
      },
      status: 'assinado'
    }

    this.salvarContrato(contratoAssinado)
    this.adicionarHistorico(contratoId, 'assinado', 'Contrato assinado digitalmente')
    
    return contratoAssinado
  }

  salvarContrato(contrato) {
    const contratos = this.listarContratos()
    const index = contratos.findIndex(c => c.id === contrato.id)
    
    if (index >= 0) {
      contratos[index] = contrato
    } else {
      contratos.push(contrato)
    }
    
    localStorage.setItem(this.storageKey, JSON.stringify(contratos))
  }

  listarContratos() {
    try {
      return JSON.parse(localStorage.getItem(this.storageKey) || '[]')
    } catch {
      return []
    }
  }

  buscarContrato(id) {
    return this.listarContratos().find(c => c.id === id)
  }

  atualizarStatus(id, novoStatus, observacao = '') {
    const contrato = this.buscarContrato(id)
    if (contrato) {
      contrato.status = novoStatus
      contrato.dataAtualizacao = new Date().toISOString()
      this.salvarContrato(contrato)
      this.adicionarHistorico(id, 'status_alterado', `Status alterado para: ${novoStatus}. ${observacao}`)
    }
  }

  adicionarHistorico(id, acao, descricao) {
    const contrato = this.buscarContrato(id)
    if (contrato) {
      if (!contrato.historico) contrato.historico = []
      contrato.historico.push({
        acao,
        descricao,
        data: new Date().toISOString(),
        usuario: 'sistema'
      })
      this.salvarContrato(contrato)
    }
  }

  getEstatisticas() {
    const contratos = this.listarContratos()
    
    return {
      total: contratos.length,
      gerados: contratos.filter(c => c.status === 'gerado').length,
      enviados: contratos.filter(c => c.status === 'enviado').length,
      assinados: contratos.filter(c => c.status === 'assinado').length,
      vencidos: contratos.filter(c => c.status === 'vencido').length,
      valorTotal: contratos
        .filter(c => c.status === 'assinado')
        .reduce((sum, c) => sum + c.valor, 0)
    }
  }
}

export const contractService = new ContractService()
```

---

**💾 RESULTADO:** Sistema completo de contratos com assinatura digital, validação e geração de PDF!

