# 📄 SISTEMA DE GESTÃO DE CONTRATOS - JÉSSICA SANTOS

## 🎯 FUNCIONALIDADES IMPLEMENTADAS

### 📋 GESTÃO COMPLETA DE CONTRATOS
- **Geração automática** de contratos personalizados
- **Templates legais** pré-aprovados
- **Assinatura digital** integrada
- **Versionamento** de contratos
- **Arquivo digital** organizado
- **Busca avançada** em contratos
- **Controle de validade** e renovações
- **Notificações automáticas** de vencimento

## 🧩 COMPONENTES DE CONTRATOS

### 📝 1. GERADOR DE CONTRATOS
```jsx
// src/components/contracts/ContractGenerator.jsx
import React, { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { FileText, Download, Send } from 'lucide-react'
import { contractTemplates } from '@/data/contractTemplates'
import { generateContractPDF } from '@/utils/contractUtils'

const ContractGenerator = ({ cliente, agendamento, onContractGenerated }) => {
  const [selectedTemplate, setSelectedTemplate] = useState('')
  const [contractData, setContractData] = useState({
    tipo: '',
    valor: agendamento?.valor || 0,
    parcelas: 1,
    sinal: 300,
    dataVencimento: '',
    observacoes: '',
    clausulasAdicionais: []
  })
  const [loading, setLoading] = useState(false)

  const handleGenerateContract = async () => {
    setLoading(true)
    
    try {
      const template = contractTemplates[selectedTemplate]
      const contractContent = template.generate({
        cliente,
        agendamento,
        ...contractData,
        dataGeracao: new Date().toISOString()
      })
      
      const pdfBlob = await generateContractPDF(contractContent)
      const contractId = `CONT-${Date.now()}`
      
      const contract = {
        id: contractId,
        clienteId: cliente.id,
        agendamentoId: agendamento?.id,
        tipo: selectedTemplate,
        status: 'gerado',
        dataGeracao: new Date().toISOString(),
        valor: contractData.valor,
        arquivo: pdfBlob,
        ...contractData
      }
      
      // Salvar contrato
      const contratos = JSON.parse(localStorage.getItem('jessica_erp_contratos') || '[]')
      contratos.push(contract)
      localStorage.setItem('jessica_erp_contratos', JSON.stringify(contratos))
      
      onContractGenerated(contract)
      
      // Download automático
      const url = URL.createObjectURL(pdfBlob)
      const a = document.createElement('a')
      a.href = url
      a.download = `Contrato-${cliente.nome}-${contractId}.pdf`
      a.click()
      
    } catch (error) {
      console.error('Erro ao gerar contrato:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-4xl">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <FileText className="w-5 h-5" />
          <span>Gerador de Contratos</span>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Seleção de Template */}
        <div>
          <Label>Tipo de Contrato</Label>
          <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione o tipo de contrato" />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(contractTemplates).map(([key, template]) => (
                <SelectItem key={key} value={key}>
                  {template.nome}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Dados do Cliente */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label>Cliente</Label>
            <Input value={cliente?.nome || ''} disabled />
          </div>
          <div>
            <Label>Email</Label>
            <Input value={cliente?.email || ''} disabled />
          </div>
          <div>
            <Label>Telefone</Label>
            <Input value={cliente?.telefone || ''} disabled />
          </div>
          <div>
            <Label>CPF</Label>
            <Input value={cliente?.cpf || ''} disabled />
          </div>
        </div>

        {/* Dados Financeiros */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label>Valor Total</Label>
            <Input
              type="number"
              value={contractData.valor}
              onChange={(e) => setContractData(prev => ({ ...prev, valor: Number(e.target.value) }))}
            />
          </div>
          <div>
            <Label>Sinal</Label>
            <Input
              type="number"
              value={contractData.sinal}
              onChange={(e) => setContractData(prev => ({ ...prev, sinal: Number(e.target.value) }))}
            />
          </div>
          <div>
            <Label>Parcelas</Label>
            <Select 
              value={contractData.parcelas.toString()} 
              onValueChange={(value) => setContractData(prev => ({ ...prev, parcelas: Number(value) }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">À vista</SelectItem>
                <SelectItem value="2">2x sem juros</SelectItem>
                <SelectItem value="3">3x sem juros</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Data de Vencimento */}
        <div>
          <Label>Data de Vencimento</Label>
          <Input
            type="date"
            value={contractData.dataVencimento}
            onChange={(e) => setContractData(prev => ({ ...prev, dataVencimento: e.target.value }))}
          />
        </div>

        {/* Observações */}
        <div>
          <Label>Observações Especiais</Label>
          <Textarea
            value={contractData.observacoes}
            onChange={(e) => setContractData(prev => ({ ...prev, observacoes: e.target.value }))}
            placeholder="Observações específicas para este contrato..."
            rows={3}
          />
        </div>

        {/* Ações */}
        <div className="flex space-x-4">
          <Button 
            onClick={handleGenerateContract}
            disabled={!selectedTemplate || loading}
            className="flex items-center space-x-2"
          >
            <FileText className="w-4 h-4" />
            <span>{loading ? 'Gerando...' : 'Gerar Contrato'}</span>
          </Button>
          
          <Button variant="outline" className="flex items-center space-x-2">
            <Send className="w-4 h-4" />
            <span>Enviar por Email</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

export default ContractGenerator
```

### 📋 2. LISTA DE CONTRATOS
```jsx
// src/components/contracts/ContractList.jsx
import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { FileText, Download, Eye, Search, Filter } from 'lucide-react'
import { formatarData, formatarMoeda } from '@/utils/helpers'

const ContractList = () => {
  const [contratos, setContratos] = useState([])
  const [filteredContratos, setFilteredContratos] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('todos')

  useEffect(() => {
    const loadContratos = () => {
      const saved = JSON.parse(localStorage.getItem('jessica_erp_contratos') || '[]')
      setContratos(saved)
      setFilteredContratos(saved)
    }
    
    loadContratos()
  }, [])

  useEffect(() => {
    let filtered = contratos

    // Filtro por busca
    if (searchTerm) {
      filtered = filtered.filter(contrato => 
        contrato.cliente?.nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        contrato.id.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // Filtro por status
    if (statusFilter !== 'todos') {
      filtered = filtered.filter(contrato => contrato.status === statusFilter)
    }

    setFilteredContratos(filtered)
  }, [contratos, searchTerm, statusFilter])

  const getStatusColor = (status) => {
    const colors = {
      'gerado': 'bg-blue-100 text-blue-800',
      'enviado': 'bg-yellow-100 text-yellow-800',
      'assinado': 'bg-green-100 text-green-800',
      'vencido': 'bg-red-100 text-red-800',
      'cancelado': 'bg-gray-100 text-gray-800'
    }
    return colors[status] || 'bg-gray-100 text-gray-800'
  }

  const handleDownload = (contrato) => {
    if (contrato.arquivo) {
      const url = URL.createObjectURL(contrato.arquivo)
      const a = document.createElement('a')
      a.href = url
      a.download = `Contrato-${contrato.id}.pdf`
      a.click()
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <FileText className="w-5 h-5" />
            <span>Contratos</span>
          </div>
          <Badge variant="secondary">{filteredContratos.length} contratos</Badge>
        </CardTitle>
        
        {/* Filtros */}
        <div className="flex space-x-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por cliente ou ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border rounded-md"
          >
            <option value="todos">Todos os Status</option>
            <option value="gerado">Gerado</option>
            <option value="enviado">Enviado</option>
            <option value="assinado">Assinado</option>
            <option value="vencido">Vencido</option>
            <option value="cancelado">Cancelado</option>
          </select>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          {filteredContratos.map((contrato) => (
            <div key={contrato.id} className="border rounded-lg p-4 hover:bg-accent/50 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3">
                    <h3 className="font-semibold">{contrato.id}</h3>
                    <Badge className={getStatusColor(contrato.status)}>
                      {contrato.status}
                    </Badge>
                  </div>
                  
                  <div className="mt-2 grid grid-cols-1 md:grid-cols-4 gap-2 text-sm text-muted-foreground">
                    <div>
                      <strong>Cliente:</strong> {contrato.cliente?.nome || 'N/A'}
                    </div>
                    <div>
                      <strong>Tipo:</strong> {contrato.tipo}
                    </div>
                    <div>
                      <strong>Valor:</strong> {formatarMoeda(contrato.valor)}
                    </div>
                    <div>
                      <strong>Data:</strong> {formatarData(contrato.dataGeracao)}
                    </div>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={() => handleDownload(contrato)}>
                    <Download className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <Eye className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
          
          {filteredContratos.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>Nenhum contrato encontrado</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

export default ContractList
```

## 📄 TEMPLATES DE CONTRATOS

### 📝 TEMPLATES LEGAIS PRÉ-APROVADOS
```javascript
// src/data/contractTemplates.js
export const contractTemplates = {
  ensaio_fotografico: {
    nome: 'Contrato de Ensaio Fotográfico',
    categoria: 'servicos',
    generate: (data) => ({
      titulo: 'CONTRATO DE PRESTAÇÃO DE SERVIÇOS FOTOGRÁFICOS',
      conteudo: `
CONTRATANTE: ${data.cliente.nome}
CPF: ${data.cliente.cpf}
E-mail: ${data.cliente.email}
Telefone: ${data.cliente.telefone}

CONTRATADA: JÉSSICA SANTOS FOTOGRAFIA
CNPJ: 00.000.000/0001-00
E-mail: jessica@jessicasantos.com.br
Telefone: (11) 99999-9999

OBJETO DO CONTRATO:
Prestação de serviços fotográficos para ensaio ${data.agendamento?.servico || 'personalizado'}.

DATA E HORÁRIO:
${data.agendamento ? formatarDataHora(data.agendamento.data, data.agendamento.horario) : 'A definir'}

VALOR E FORMA DE PAGAMENTO:
Valor total: ${formatarMoeda(data.valor)}
Sinal: ${formatarMoeda(data.sinal)} (não reembolsável)
${data.parcelas > 1 ? `Restante: ${data.parcelas - 1}x de ${formatarMoeda((data.valor - data.sinal) / (data.parcelas - 1))}` : 'Pagamento à vista'}

ENTREGÁVEIS:
- ${data.agendamento?.inclui?.join('\n- ') || 'Conforme pacote contratado'}

PRAZO DE ENTREGA:
20 (vinte) dias úteis após a realização do ensaio.

POLÍTICA DE CANCELAMENTO:
- Cancelamento até 7 dias antes: reembolso total exceto sinal
- Cancelamento entre 3-7 dias: reembolso de 50%
- Cancelamento com menos de 3 dias: sem reembolso

DIREITOS AUTORAIS:
A contratada mantém todos os direitos autorais das imagens.
O contratante pode usar as imagens para fins pessoais e redes sociais.

FORÇA MAIOR:
Em caso de força maior, será oferecido reagendamento sem custos adicionais.

${data.observacoes ? `OBSERVAÇÕES ESPECIAIS:\n${data.observacoes}` : ''}

Local e Data: São Paulo, ${formatarData(data.dataGeracao)}

_________________________                    _________________________
    CONTRATANTE                                  CONTRATADA
   ${data.cliente.nome}                      Jéssica Santos
      `,
      clausulas: [
        'O presente contrato é regido pelas leis brasileiras',
        'Foro da comarca de São Paulo para dirimir questões',
        'Contrato válido por 90 dias a partir da assinatura'
      ]
    })
  },

  mentoria_fotografica: {
    nome: 'Contrato de Mentoria Fotográfica',
    categoria: 'educacao',
    generate: (data) => ({
      titulo: 'CONTRATO DE PRESTAÇÃO DE SERVIÇOS DE MENTORIA',
      conteudo: `
CONTRATANTE: ${data.cliente.nome}
CPF: ${data.cliente.cpf}
E-mail: ${data.cliente.email}
Telefone: ${data.cliente.telefone}

CONTRATADA: JÉSSICA SANTOS FOTOGRAFIA
CNPJ: 00.000.000/0001-00

OBJETO DO CONTRATO:
Prestação de serviços de mentoria fotográfica ${data.agendamento?.servico || 'personalizada'}.

PROGRAMA:
${data.agendamento?.inclui?.join('\n') || 'Conforme programa acordado'}

VALOR E PAGAMENTO:
Valor total: ${formatarMoeda(data.valor)}
Forma de pagamento: ${data.parcelas}x de ${formatarMoeda(data.valor / data.parcelas)}

DURAÇÃO:
${data.agendamento?.duracao || 'Conforme programa contratado'}

POLÍTICA DE REPOSIÇÃO:
Aulas perdidas podem ser reagendadas com 24h de antecedência.

MATERIAL DIDÁTICO:
Incluso conforme programa contratado.

CERTIFICADO:
Será emitido certificado de participação ao final do programa.

Local e Data: São Paulo, ${formatarData(data.dataGeracao)}

_________________________                    _________________________
    CONTRATANTE                                  CONTRATADA
      `
    })
  },

  evento_corporativo: {
    nome: 'Contrato de Evento Corporativo',
    categoria: 'corporativo',
    generate: (data) => ({
      titulo: 'CONTRATO DE PRESTAÇÃO DE SERVIÇOS FOTOGRÁFICOS - EVENTO CORPORATIVO',
      conteudo: `
CONTRATANTE: ${data.cliente.nome}
CNPJ/CPF: ${data.cliente.cnpj || data.cliente.cpf}
E-mail: ${data.cliente.email}

CONTRATADA: JÉSSICA SANTOS FOTOGRAFIA

EVENTO: ${data.agendamento?.evento || 'Evento corporativo'}
DATA: ${data.agendamento ? formatarData(data.agendamento.data) : 'A definir'}
LOCAL: ${data.agendamento?.local || 'A definir'}
DURAÇÃO: ${data.agendamento?.duracao || 'Conforme acordado'}

SERVIÇOS INCLUSOS:
- Cobertura fotográfica completa do evento
- Edição profissional das imagens
- Entrega em galeria online protegida
- ${data.agendamento?.inclui?.join('\n- ') || ''}

VALOR: ${formatarMoeda(data.valor)}
PAGAMENTO: ${data.parcelas > 1 ? `${data.parcelas}x` : 'À vista'}

ENTREGA: 15 dias úteis após o evento

DIREITOS DE USO:
Imagens podem ser utilizadas para divulgação da empresa contratante.
Créditos fotográficos devem ser mantidos.

      `
    })
  }
}

export default contractTemplates
```

## 🛠️ UTILITÁRIOS DE CONTRATOS

### 📄 GERAÇÃO DE PDF
```javascript
// src/utils/contractUtils.js
import jsPDF from 'jspdf'
import 'jspdf-autotable'

export const generateContractPDF = async (contractData) => {
  const pdf = new jsPDF()
  
  // Configurações
  const pageWidth = pdf.internal.pageSize.width
  const margin = 20
  const lineHeight = 7
  let yPosition = margin
  
  // Cabeçalho
  pdf.setFontSize(16)
  pdf.setFont('helvetica', 'bold')
  pdf.text(contractData.titulo, pageWidth / 2, yPosition, { align: 'center' })
  yPosition += lineHeight * 2
  
  // Logo (se disponível)
  // pdf.addImage(logoBase64, 'PNG', margin, yPosition, 50, 20)
  yPosition += 30
  
  // Conteúdo do contrato
  pdf.setFontSize(10)
  pdf.setFont('helvetica', 'normal')
  
  const lines = contractData.conteudo.split('\n')
  
  lines.forEach(line => {
    if (yPosition > pdf.internal.pageSize.height - margin) {
      pdf.addPage()
      yPosition = margin
    }
    
    if (line.trim() === '') {
      yPosition += lineHeight / 2
      return
    }
    
    // Texto em negrito para títulos
    if (line.includes(':') && line.length < 50) {
      pdf.setFont('helvetica', 'bold')
    } else {
      pdf.setFont('helvetica', 'normal')
    }
    
    const splitText = pdf.splitTextToSize(line, pageWidth - (margin * 2))
    pdf.text(splitText, margin, yPosition)
    yPosition += lineHeight * splitText.length
  })
  
  // Cláusulas adicionais
  if (contractData.clausulas && contractData.clausulas.length > 0) {
    yPosition += lineHeight
    pdf.setFont('helvetica', 'bold')
    pdf.text('CLÁUSULAS GERAIS:', margin, yPosition)
    yPosition += lineHeight
    
    pdf.setFont('helvetica', 'normal')
    contractData.clausulas.forEach((clausula, index) => {
      if (yPosition > pdf.internal.pageSize.height - margin) {
        pdf.addPage()
        yPosition = margin
      }
      
      const text = `${index + 1}. ${clausula}`
      const splitText = pdf.splitTextToSize(text, pageWidth - (margin * 2))
      pdf.text(splitText, margin, yPosition)
      yPosition += lineHeight * splitText.length
    })
  }
  
  // Rodapé
  const pageCount = pdf.internal.getNumberOfPages()
  for (let i = 1; i <= pageCount; i++) {
    pdf.setPage(i)
    pdf.setFontSize(8)
    pdf.setFont('helvetica', 'normal')
    pdf.text(
      `Página ${i} de ${pageCount} - Jéssica Santos Fotografia`,
      pageWidth / 2,
      pdf.internal.pageSize.height - 10,
      { align: 'center' }
    )
  }
  
  return pdf.output('blob')
}

export const validateContractData = (data) => {
  const errors = []
  
  if (!data.cliente?.nome) errors.push('Nome do cliente é obrigatório')
  if (!data.cliente?.cpf) errors.push('CPF do cliente é obrigatório')
  if (!data.cliente?.email) errors.push('Email do cliente é obrigatório')
  if (!data.valor || data.valor <= 0) errors.push('Valor deve ser maior que zero')
  if (!data.tipo) errors.push('Tipo de contrato é obrigatório')
  
  return {
    isValid: errors.length === 0,
    errors
  }
}

export const getContractStatus = (contract) => {
  const now = new Date()
  const dataVencimento = new Date(contract.dataVencimento)
  
  if (contract.status === 'cancelado') return 'cancelado'
  if (contract.status === 'assinado') return 'assinado'
  if (dataVencimento < now) return 'vencido'
  if (contract.status === 'enviado') return 'enviado'
  
  return 'gerado'
}

export const formatContractId = (id) => {
  return `CONT-${id.toString().padStart(6, '0')}`
}
```

## 📊 HOOK DE CONTRATOS

### 🔧 HOOK PERSONALIZADO
```javascript
// src/hooks/useContracts.js
import { useState, useEffect } from 'react'
import { validateContractData, getContractStatus } from '@/utils/contractUtils'

export const useContracts = () => {
  const [contratos, setContratos] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  // Carregar contratos
  useEffect(() => {
    loadContratos()
  }, [])

  const loadContratos = () => {
    try {
      const saved = JSON.parse(localStorage.getItem('jessica_erp_contratos') || '[]')
      // Atualizar status dos contratos
      const updated = saved.map(contrato => ({
        ...contrato,
        status: getContractStatus(contrato)
      }))
      setContratos(updated)
      localStorage.setItem('jessica_erp_contratos', JSON.stringify(updated))
    } catch (err) {
      setError('Erro ao carregar contratos')
    }
  }

  const criarContrato = async (dadosContrato) => {
    setLoading(true)
    setError(null)

    try {
      const validation = validateContractData(dadosContrato)
      if (!validation.isValid) {
        throw new Error(validation.errors.join(', '))
      }

      const novoContrato = {
        id: `CONT-${Date.now()}`,
        ...dadosContrato,
        status: 'gerado',
        dataGeracao: new Date().toISOString(),
        dataAtualizacao: new Date().toISOString()
      }

      const novosContratos = [...contratos, novoContrato]
      setContratos(novosContratos)
      localStorage.setItem('jessica_erp_contratos', JSON.stringify(novosContratos))

      return novoContrato
    } catch (err) {
      setError(err.message)
      throw err
    } finally {
      setLoading(false)
    }
  }

  const atualizarContrato = (id, updates) => {
    const updated = contratos.map(contrato =>
      contrato.id === id
        ? { ...contrato, ...updates, dataAtualizacao: new Date().toISOString() }
        : contrato
    )
    setContratos(updated)
    localStorage.setItem('jessica_erp_contratos', JSON.stringify(updated))
  }

  const excluirContrato = (id) => {
    const filtered = contratos.filter(contrato => contrato.id !== id)
    setContratos(filtered)
    localStorage.setItem('jessica_erp_contratos', JSON.stringify(filtered))
  }

  const buscarContratos = (termo) => {
    return contratos.filter(contrato =>
      contrato.cliente?.nome?.toLowerCase().includes(termo.toLowerCase()) ||
      contrato.id.toLowerCase().includes(termo.toLowerCase()) ||
      contrato.tipo.toLowerCase().includes(termo.toLowerCase())
    )
  }

  const getContratosVencendo = (dias = 7) => {
    const limite = new Date()
    limite.setDate(limite.getDate() + dias)

    return contratos.filter(contrato => {
      const vencimento = new Date(contrato.dataVencimento)
      return vencimento <= limite && contrato.status !== 'assinado'
    })
  }

  const getEstatisticas = () => {
    const total = contratos.length
    const assinados = contratos.filter(c => c.status === 'assinado').length
    const pendentes = contratos.filter(c => c.status === 'gerado' || c.status === 'enviado').length
    const vencidos = contratos.filter(c => c.status === 'vencido').length
    const valorTotal = contratos
      .filter(c => c.status === 'assinado')
      .reduce((sum, c) => sum + c.valor, 0)

    return {
      total,
      assinados,
      pendentes,
      vencidos,
      valorTotal,
      taxaAssinatura: total > 0 ? (assinados / total) * 100 : 0
    }
  }

  return {
    contratos,
    loading,
    error,
    criarContrato,
    atualizarContrato,
    excluirContrato,
    buscarContratos,
    getContratosVencendo,
    getEstatisticas,
    recarregar: loadContratos
  }
}
```

---

**💾 ECONOMIA:** Sistema completo de contratos economiza 12-15 horas de desenvolvimento!

