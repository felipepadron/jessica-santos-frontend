# 🛡️ SISTEMA DE MARCA D'ÁGUA E PROTEÇÃO - JÉSSICA SANTOS

## 🎯 FUNCIONALIDADES DE PROTEÇÃO IMPLEMENTADAS

### 🏷️ SISTEMA DE MARCA D'ÁGUA
- **Upload de logos** personalizadas da Jéssica
- **Aplicação automática** em fotos de preview
- **Configuração de posição** e transparência
- **Diferentes tipos** de marca d'água por contexto
- **Processamento em lote** de imagens
- **Qualidade otimizada** para web

### 🔒 PROTEÇÃO CONTRA CÓPIAS
- **Bloqueio de print screen** na galeria
- **Proteção contra clique direito** nas imagens
- **Overlay invisível** sobre as fotos
- **Detecção de ferramentas** de captura
- **Alertas de tentativa** de cópia
- **Watermark dinâmico** com dados do cliente

## 🧩 COMPONENTES DE PROTEÇÃO

### ⚙️ CONFIGURAÇÃO DE MARCA D'ÁGUA
```jsx
// src/components/setup/WatermarkSetup.jsx
import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Upload, 
  Image, 
  Shield, 
  Eye, 
  Download,
  Trash2,
  RotateCcw,
  Move,
  Palette
} from 'lucide-react'

const WatermarkSetup = ({ data = {}, onComplete }) => {
  const [watermarkConfig, setWatermarkConfig] = useState({
    enabled: true,
    logos: {
      main: null, // Logo principal
      signature: null, // Assinatura
      minimal: null // Logo minimalista
    },
    settings: {
      position: 'bottom-right', // top-left, top-right, bottom-left, bottom-right, center
      opacity: 70, // 0-100
      size: 15, // % da imagem
      margin: 20, // pixels da borda
      rotation: 0, // graus
      type: 'logo', // logo, text, both
      textWatermark: 'Jéssica Santos Fotografia',
      fontFamily: 'Arial',
      fontSize: 24,
      fontColor: '#ffffff',
      shadowEnabled: true,
      shadowColor: '#000000',
      shadowBlur: 4
    },
    protection: {
      disableRightClick: true,
      disablePrintScreen: true,
      disableDevTools: true,
      overlayProtection: true,
      dynamicWatermark: true, // Inclui dados do cliente
      blurOnInactivity: false
    },
    contexts: {
      gallery: { // Galeria de seleção
        enabled: true,
        opacity: 80,
        size: 20,
        position: 'center'
      },
      preview: { // Preview para aprovação
        enabled: true,
        opacity: 60,
        size: 15,
        position: 'bottom-right'
      },
      social: { // Compartilhamento social
        enabled: true,
        opacity: 90,
        size: 25,
        position: 'bottom-center'
      }
    },
    ...data
  })

  const [previewImage, setPreviewImage] = useState('/api/placeholder/400/300')
  const [selectedLogo, setSelectedLogo] = useState(null)

  useEffect(() => {
    onComplete(watermarkConfig)
  }, [watermarkConfig, onComplete])

  const handleLogoUpload = (type, file) => {
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setWatermarkConfig(prev => ({
          ...prev,
          logos: {
            ...prev.logos,
            [type]: {
              file: e.target.result,
              name: file.name,
              size: file.size
            }
          }
        }))
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSettingChange = (setting, value) => {
    setWatermarkConfig(prev => ({
      ...prev,
      settings: {
        ...prev.settings,
        [setting]: value
      }
    }))
  }

  const handleProtectionChange = (setting, value) => {
    setWatermarkConfig(prev => ({
      ...prev,
      protection: {
        ...prev.protection,
        [setting]: value
      }
    }))
  }

  const handleContextChange = (context, setting, value) => {
    setWatermarkConfig(prev => ({
      ...prev,
      contexts: {
        ...prev.contexts,
        [context]: {
          ...prev.contexts[context],
          [setting]: value
        }
      }
    }))
  }

  const positions = [
    { value: 'top-left', label: 'Superior Esquerda' },
    { value: 'top-center', label: 'Superior Centro' },
    { value: 'top-right', label: 'Superior Direita' },
    { value: 'center-left', label: 'Centro Esquerda' },
    { value: 'center', label: 'Centro' },
    { value: 'center-right', label: 'Centro Direita' },
    { value: 'bottom-left', label: 'Inferior Esquerda' },
    { value: 'bottom-center', label: 'Inferior Centro' },
    { value: 'bottom-right', label: 'Inferior Direita' }
  ]

  const fonts = [
    'Arial', 'Helvetica', 'Times New Roman', 'Georgia', 
    'Verdana', 'Trebuchet MS', 'Impact', 'Comic Sans MS'
  ]

  return (
    <div className="space-y-6">
      <Alert>
        <Shield className="w-4 h-4" />
        <AlertDescription>
          Configure marca d'água e proteções para suas fotos. 
          Isso protege seu trabalho contra cópias não autorizadas.
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="logos" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="logos">Logos</TabsTrigger>
          <TabsTrigger value="settings">Configurações</TabsTrigger>
          <TabsTrigger value="protection">Proteção</TabsTrigger>
          <TabsTrigger value="contexts">Contextos</TabsTrigger>
        </TabsList>

        {/* Upload de Logos */}
        <TabsContent value="logos">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Image className="w-5 h-5" />
                <span>Upload de Logos</span>
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Logo Principal */}
              <div>
                <Label className="text-base font-medium">Logo Principal</Label>
                <p className="text-sm text-muted-foreground mb-3">
                  Logo completo da Jéssica Santos Fotografia (recomendado: PNG com fundo transparente)
                </p>
                
                <div className="flex items-center space-x-4">
                  {watermarkConfig.logos.main ? (
                    <div className="flex items-center space-x-3">
                      <img 
                        src={watermarkConfig.logos.main.file} 
                        alt="Logo principal"
                        className="w-20 h-20 object-contain border rounded"
                      />
                      <div>
                        <p className="font-medium">{watermarkConfig.logos.main.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {(watermarkConfig.logos.main.size / 1024).toFixed(1)} KB
                        </p>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setWatermarkConfig(prev => ({
                          ...prev,
                          logos: { ...prev.logos, main: null }
                        }))}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-muted rounded-lg p-6 text-center">
                      <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground mb-2">
                        Arraste o logo aqui ou clique para selecionar
                      </p>
                      <Button variant="outline" asChild>
                        <label>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleLogoUpload('main', e.target.files[0])}
                            className="hidden"
                          />
                          Selecionar Logo Principal
                        </label>
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              {/* Assinatura */}
              <div>
                <Label className="text-base font-medium">Assinatura</Label>
                <p className="text-sm text-muted-foreground mb-3">
                  Assinatura pessoal da Jéssica (para fotos mais artísticas)
                </p>
                
                <div className="flex items-center space-x-4">
                  {watermarkConfig.logos.signature ? (
                    <div className="flex items-center space-x-3">
                      <img 
                        src={watermarkConfig.logos.signature.file} 
                        alt="Assinatura"
                        className="w-20 h-20 object-contain border rounded"
                      />
                      <div>
                        <p className="font-medium">{watermarkConfig.logos.signature.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {(watermarkConfig.logos.signature.size / 1024).toFixed(1)} KB
                        </p>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setWatermarkConfig(prev => ({
                          ...prev,
                          logos: { ...prev.logos, signature: null }
                        }))}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-muted rounded-lg p-6 text-center">
                      <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                      <Button variant="outline" asChild>
                        <label>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleLogoUpload('signature', e.target.files[0])}
                            className="hidden"
                          />
                          Selecionar Assinatura
                        </label>
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              {/* Logo Minimalista */}
              <div>
                <Label className="text-base font-medium">Logo Minimalista</Label>
                <p className="text-sm text-muted-foreground mb-3">
                  Versão simplificada para fotos pequenas ou redes sociais
                </p>
                
                <div className="flex items-center space-x-4">
                  {watermarkConfig.logos.minimal ? (
                    <div className="flex items-center space-x-3">
                      <img 
                        src={watermarkConfig.logos.minimal.file} 
                        alt="Logo minimalista"
                        className="w-20 h-20 object-contain border rounded"
                      />
                      <div>
                        <p className="font-medium">{watermarkConfig.logos.minimal.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {(watermarkConfig.logos.minimal.size / 1024).toFixed(1)} KB
                        </p>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setWatermarkConfig(prev => ({
                          ...prev,
                          logos: { ...prev.logos, minimal: null }
                        }))}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-muted rounded-lg p-6 text-center">
                      <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                      <Button variant="outline" asChild>
                        <label>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleLogoUpload('minimal', e.target.files[0])}
                            className="hidden"
                          />
                          Selecionar Logo Minimalista
                        </label>
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Configurações */}
        <TabsContent value="settings">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Configurações Gerais */}
            <Card>
              <CardHeader>
                <CardTitle>Configurações Gerais</CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Marca d'água ativada</Label>
                  <Switch
                    checked={watermarkConfig.enabled}
                    onCheckedChange={(checked) => setWatermarkConfig(prev => ({
                      ...prev,
                      enabled: checked
                    }))}
                  />
                </div>

                <div>
                  <Label>Tipo de marca d'água</Label>
                  <Select
                    value={watermarkConfig.settings.type}
                    onValueChange={(value) => handleSettingChange('type', value)}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="logo">Apenas Logo</SelectItem>
                      <SelectItem value="text">Apenas Texto</SelectItem>
                      <SelectItem value="both">Logo + Texto</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Posição</Label>
                  <Select
                    value={watermarkConfig.settings.position}
                    onValueChange={(value) => handleSettingChange('position', value)}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {positions.map(pos => (
                        <SelectItem key={pos.value} value={pos.value}>
                          {pos.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Opacidade: {watermarkConfig.settings.opacity}%</Label>
                  <Slider
                    value={[watermarkConfig.settings.opacity]}
                    onValueChange={([value]) => handleSettingChange('opacity', value)}
                    max={100}
                    step={5}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Tamanho: {watermarkConfig.settings.size}%</Label>
                  <Slider
                    value={[watermarkConfig.settings.size]}
                    onValueChange={([value]) => handleSettingChange('size', value)}
                    min={5}
                    max={50}
                    step={1}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Margem: {watermarkConfig.settings.margin}px</Label>
                  <Slider
                    value={[watermarkConfig.settings.margin]}
                    onValueChange={([value]) => handleSettingChange('margin', value)}
                    min={0}
                    max={100}
                    step={5}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Rotação: {watermarkConfig.settings.rotation}°</Label>
                  <Slider
                    value={[watermarkConfig.settings.rotation]}
                    onValueChange={([value]) => handleSettingChange('rotation', value)}
                    min={-45}
                    max={45}
                    step={5}
                    className="mt-2"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Configurações de Texto */}
            <Card>
              <CardHeader>
                <CardTitle>Configurações de Texto</CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div>
                  <Label>Texto da marca d'água</Label>
                  <Input
                    value={watermarkConfig.settings.textWatermark}
                    onChange={(e) => handleSettingChange('textWatermark', e.target.value)}
                    placeholder="Jéssica Santos Fotografia"
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Fonte</Label>
                  <Select
                    value={watermarkConfig.settings.fontFamily}
                    onValueChange={(value) => handleSettingChange('fontFamily', value)}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {fonts.map(font => (
                        <SelectItem key={font} value={font}>
                          {font}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Tamanho da fonte: {watermarkConfig.settings.fontSize}px</Label>
                  <Slider
                    value={[watermarkConfig.settings.fontSize]}
                    onValueChange={([value]) => handleSettingChange('fontSize', value)}
                    min={12}
                    max={72}
                    step={2}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Cor do texto</Label>
                  <div className="flex items-center space-x-2 mt-2">
                    <Input
                      type="color"
                      value={watermarkConfig.settings.fontColor}
                      onChange={(e) => handleSettingChange('fontColor', e.target.value)}
                      className="w-12 h-10 p-1"
                    />
                    <Input
                      value={watermarkConfig.settings.fontColor}
                      onChange={(e) => handleSettingChange('fontColor', e.target.value)}
                      placeholder="#ffffff"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <Label>Sombra no texto</Label>
                  <Switch
                    checked={watermarkConfig.settings.shadowEnabled}
                    onCheckedChange={(checked) => handleSettingChange('shadowEnabled', checked)}
                  />
                </div>

                {watermarkConfig.settings.shadowEnabled && (
                  <>
                    <div>
                      <Label>Cor da sombra</Label>
                      <div className="flex items-center space-x-2 mt-2">
                        <Input
                          type="color"
                          value={watermarkConfig.settings.shadowColor}
                          onChange={(e) => handleSettingChange('shadowColor', e.target.value)}
                          className="w-12 h-10 p-1"
                        />
                        <Input
                          value={watermarkConfig.settings.shadowColor}
                          onChange={(e) => handleSettingChange('shadowColor', e.target.value)}
                          placeholder="#000000"
                        />
                      </div>
                    </div>

                    <div>
                      <Label>Desfoque da sombra: {watermarkConfig.settings.shadowBlur}px</Label>
                      <Slider
                        value={[watermarkConfig.settings.shadowBlur]}
                        onValueChange={([value]) => handleSettingChange('shadowBlur', value)}
                        min={0}
                        max={20}
                        step={1}
                        className="mt-2"
                      />
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Preview */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Eye className="w-5 h-5" />
                <span>Preview da Marca d'água</span>
              </CardTitle>
            </CardHeader>
            
            <CardContent>
              <div className="relative inline-block">
                <img
                  src={previewImage}
                  alt="Preview"
                  className="max-w-md rounded-lg"
                />
                {/* Aqui seria renderizada a marca d'água simulada */}
                <div 
                  className="absolute pointer-events-none"
                  style={{
                    [watermarkConfig.settings.position.includes('top') ? 'top' : 'bottom']: 
                      `${watermarkConfig.settings.margin}px`,
                    [watermarkConfig.settings.position.includes('left') ? 'left' : 
                     watermarkConfig.settings.position.includes('right') ? 'right' : 'left']: 
                      watermarkConfig.settings.position.includes('center') ? '50%' : 
                      `${watermarkConfig.settings.margin}px`,
                    transform: watermarkConfig.settings.position.includes('center') ? 
                      'translateX(-50%)' : 'none',
                    opacity: watermarkConfig.settings.opacity / 100,
                    fontSize: `${watermarkConfig.settings.fontSize}px`,
                    fontFamily: watermarkConfig.settings.fontFamily,
                    color: watermarkConfig.settings.fontColor,
                    textShadow: watermarkConfig.settings.shadowEnabled ? 
                      `${watermarkConfig.settings.shadowBlur}px ${watermarkConfig.settings.shadowBlur}px ${watermarkConfig.settings.shadowBlur}px ${watermarkConfig.settings.shadowColor}` : 
                      'none',
                    transform: `rotate(${watermarkConfig.settings.rotation}deg)`
                  }}
                >
                  {watermarkConfig.settings.type !== 'logo' && watermarkConfig.settings.textWatermark}
                </div>
              </div>
              
              <div className="mt-4 flex space-x-2">
                <Button variant="outline" size="sm">
                  <Upload className="w-4 h-4 mr-2" />
                  Testar com sua foto
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Baixar preview
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Proteção */}
        <TabsContent value="protection">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="w-5 h-5" />
                <span>Proteções Anti-Cópia</span>
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Desabilitar clique direito</Label>
                    <p className="text-sm text-muted-foreground">
                      Impede menu de contexto e "Salvar imagem como"
                    </p>
                  </div>
                  <Switch
                    checked={watermarkConfig.protection.disableRightClick}
                    onCheckedChange={(checked) => handleProtectionChange('disableRightClick', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Bloquear Print Screen</Label>
                    <p className="text-sm text-muted-foreground">
                      Detecta e bloqueia tentativas de captura de tela
                    </p>
                  </div>
                  <Switch
                    checked={watermarkConfig.protection.disablePrintScreen}
                    onCheckedChange={(checked) => handleProtectionChange('disablePrintScreen', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Desabilitar ferramentas de desenvolvedor</Label>
                    <p className="text-sm text-muted-foreground">
                      Impede acesso ao código fonte e inspeção de elementos
                    </p>
                  </div>
                  <Switch
                    checked={watermarkConfig.protection.disableDevTools}
                    onCheckedChange={(checked) => handleProtectionChange('disableDevTools', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Overlay de proteção</Label>
                    <p className="text-sm text-muted-foreground">
                      Camada invisível sobre as imagens para impedir seleção
                    </p>
                  </div>
                  <Switch
                    checked={watermarkConfig.protection.overlayProtection}
                    onCheckedChange={(checked) => handleProtectionChange('overlayProtection', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Marca d'água dinâmica</Label>
                    <p className="text-sm text-muted-foreground">
                      Inclui nome do cliente e data na marca d'água
                    </p>
                  </div>
                  <Switch
                    checked={watermarkConfig.protection.dynamicWatermark}
                    onCheckedChange={(checked) => handleProtectionChange('dynamicWatermark', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Desfoque por inatividade</Label>
                    <p className="text-sm text-muted-foreground">
                      Desfoca imagens quando usuário fica inativo
                    </p>
                  </div>
                  <Switch
                    checked={watermarkConfig.protection.blurOnInactivity}
                    onCheckedChange={(checked) => handleProtectionChange('blurOnInactivity', checked)}
                  />
                </div>
              </div>

              <Alert>
                <Shield className="w-4 h-4" />
                <AlertDescription>
                  <strong>Importante:</strong> Essas proteções aumentam a segurança, mas podem afetar a experiência do usuário. 
                  Teste com clientes antes de ativar todas as opções.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Contextos */}
        <TabsContent value="contexts">
          <div className="space-y-6">
            <Alert>
              <Eye className="w-4 h-4" />
              <AlertDescription>
                Configure diferentes configurações de marca d'água para cada contexto de uso.
              </AlertDescription>
            </Alert>

            {/* Galeria de Seleção */}
            <Card>
              <CardHeader>
                <CardTitle>Galeria de Seleção</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Configurações para fotos na galeria de seleção do cliente
                </p>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Ativado</Label>
                  <Switch
                    checked={watermarkConfig.contexts.gallery.enabled}
                    onCheckedChange={(checked) => handleContextChange('gallery', 'enabled', checked)}
                  />
                </div>

                <div>
                  <Label>Opacidade: {watermarkConfig.contexts.gallery.opacity}%</Label>
                  <Slider
                    value={[watermarkConfig.contexts.gallery.opacity]}
                    onValueChange={([value]) => handleContextChange('gallery', 'opacity', value)}
                    max={100}
                    step={5}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Tamanho: {watermarkConfig.contexts.gallery.size}%</Label>
                  <Slider
                    value={[watermarkConfig.contexts.gallery.size]}
                    onValueChange={([value]) => handleContextChange('gallery', 'size', value)}
                    min={5}
                    max={50}
                    step={1}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Posição</Label>
                  <Select
                    value={watermarkConfig.contexts.gallery.position}
                    onValueChange={(value) => handleContextChange('gallery', 'position', value)}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {positions.map(pos => (
                        <SelectItem key={pos.value} value={pos.value}>
                          {pos.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Preview para Aprovação */}
            <Card>
              <CardHeader>
                <CardTitle>Preview para Aprovação</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Configurações para fotos enviadas para aprovação de edição
                </p>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Ativado</Label>
                  <Switch
                    checked={watermarkConfig.contexts.preview.enabled}
                    onCheckedChange={(checked) => handleContextChange('preview', 'enabled', checked)}
                  />
                </div>

                <div>
                  <Label>Opacidade: {watermarkConfig.contexts.preview.opacity}%</Label>
                  <Slider
                    value={[watermarkConfig.contexts.preview.opacity]}
                    onValueChange={([value]) => handleContextChange('preview', 'opacity', value)}
                    max={100}
                    step={5}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Tamanho: {watermarkConfig.contexts.preview.size}%</Label>
                  <Slider
                    value={[watermarkConfig.contexts.preview.size]}
                    onValueChange={([value]) => handleContextChange('preview', 'size', value)}
                    min={5}
                    max={50}
                    step={1}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Posição</Label>
                  <Select
                    value={watermarkConfig.contexts.preview.position}
                    onValueChange={(value) => handleContextChange('preview', 'position', value)}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {positions.map(pos => (
                        <SelectItem key={pos.value} value={pos.value}>
                          {pos.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Compartilhamento Social */}
            <Card>
              <CardHeader>
                <CardTitle>Compartilhamento Social</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Configurações para fotos compartilhadas em redes sociais
                </p>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Ativado</Label>
                  <Switch
                    checked={watermarkConfig.contexts.social.enabled}
                    onCheckedChange={(checked) => handleContextChange('social', 'enabled', checked)}
                  />
                </div>

                <div>
                  <Label>Opacidade: {watermarkConfig.contexts.social.opacity}%</Label>
                  <Slider
                    value={[watermarkConfig.contexts.social.opacity]}
                    onValueChange={([value]) => handleContextChange('social', 'opacity', value)}
                    max={100}
                    step={5}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Tamanho: {watermarkConfig.contexts.social.size}%</Label>
                  <Slider
                    value={[watermarkConfig.contexts.social.size]}
                    onValueChange={([value]) => handleContextChange('social', 'size', value)}
                    min={5}
                    max={50}
                    step={1}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label>Posição</Label>
                  <Select
                    value={watermarkConfig.contexts.social.position}
                    onValueChange={(value) => handleContextChange('social', 'position', value)}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {positions.map(pos => (
                        <SelectItem key={pos.value} value={pos.value}>
                          {pos.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Status */}
      <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
        <span className="text-sm">
          ✅ Sistema de marca d'água e proteção configurado
        </span>
        <div className="flex items-center space-x-2">
          {watermarkConfig.enabled && (
            <Badge variant="default">Proteção Ativa</Badge>
          )}
          {Object.values(watermarkConfig.logos).some(logo => logo) && (
            <Badge variant="outline">Logos Carregados</Badge>
          )}
        </div>
      </div>
    </div>
  )
}

export default WatermarkSetup
```

### 🛡️ COMPONENTE DE PROTEÇÃO DA GALERIA
```jsx
// src/components/gallery/ProtectedGallery.jsx
import React, { useEffect, useState } from 'react'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Shield, Eye, AlertTriangle } from 'lucide-react'

const ProtectedGallery = ({ children, watermarkConfig, clientData }) => {
  const [protectionActive, setProtectionActive] = useState(false)
  const [warningCount, setWarningCount] = useState(0)

  useEffect(() => {
    if (!watermarkConfig?.protection) return

    const { 
      disableRightClick, 
      disablePrintScreen, 
      disableDevTools, 
      overlayProtection 
    } = watermarkConfig.protection

    // Desabilitar clique direito
    if (disableRightClick) {
      const handleContextMenu = (e) => {
        e.preventDefault()
        showWarning('Clique direito desabilitado para proteger as imagens.')
        return false
      }
      document.addEventListener('contextmenu', handleContextMenu)
    }

    // Desabilitar seleção de texto/imagem
    if (overlayProtection) {
      const style = document.createElement('style')
      style.textContent = `
        .protected-gallery img {
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
          -webkit-user-drag: none;
          -khtml-user-drag: none;
          -moz-user-drag: none;
          -o-user-drag: none;
          user-drag: none;
          pointer-events: none;
        }
        .protected-gallery .image-overlay {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: 10;
          background: transparent;
        }
      `
      document.head.appendChild(style)
    }

    // Bloquear Print Screen
    if (disablePrintScreen) {
      const handleKeyDown = (e) => {
        // Print Screen
        if (e.keyCode === 44) {
          e.preventDefault()
          showWarning('Captura de tela não permitida.')
          return false
        }
        // Ctrl+P (Imprimir)
        if (e.ctrlKey && e.keyCode === 80) {
          e.preventDefault()
          showWarning('Impressão não permitida.')
          return false
        }
        // Ctrl+S (Salvar)
        if (e.ctrlKey && e.keyCode === 83) {
          e.preventDefault()
          showWarning('Salvamento direto não permitido.')
          return false
        }
      }
      document.addEventListener('keydown', handleKeyDown)
    }

    // Desabilitar ferramentas de desenvolvedor
    if (disableDevTools) {
      const handleKeyDown = (e) => {
        // F12
        if (e.keyCode === 123) {
          e.preventDefault()
          showWarning('Ferramentas de desenvolvedor desabilitadas.')
          return false
        }
        // Ctrl+Shift+I
        if (e.ctrlKey && e.shiftKey && e.keyCode === 73) {
          e.preventDefault()
          showWarning('Inspeção de elementos não permitida.')
          return false
        }
        // Ctrl+Shift+C
        if (e.ctrlKey && e.shiftKey && e.keyCode === 67) {
          e.preventDefault()
          showWarning('Seleção de elementos não permitida.')
          return false
        }
        // Ctrl+U (View Source)
        if (e.ctrlKey && e.keyCode === 85) {
          e.preventDefault()
          showWarning('Visualização do código fonte não permitida.')
          return false
        }
      }
      document.addEventListener('keydown', handleKeyDown)
    }

    // Detectar ferramentas de desenvolvedor abertas
    if (disableDevTools) {
      const detectDevTools = () => {
        const threshold = 160
        if (window.outerHeight - window.innerHeight > threshold || 
            window.outerWidth - window.innerWidth > threshold) {
          showWarning('Ferramentas de desenvolvedor detectadas. Fechando galeria por segurança.')
          // Opcional: redirecionar ou fechar
        }
      }
      setInterval(detectDevTools, 1000)
    }

    setProtectionActive(true)

    // Cleanup
    return () => {
      if (disableRightClick) {
        document.removeEventListener('contextmenu', () => {})
      }
      if (disablePrintScreen || disableDevTools) {
        document.removeEventListener('keydown', () => {})
      }
    }
  }, [watermarkConfig])

  const showWarning = (message) => {
    setWarningCount(prev => prev + 1)
    // Mostrar toast ou modal de aviso
    console.warn(message)
    
    // Se muitas tentativas, pode bloquear acesso
    if (warningCount > 5) {
      alert('Muitas tentativas de acesso não autorizado. Contate a fotógrafa.')
    }
  }

  // Aplicar marca d'água dinâmica
  const getDynamicWatermark = () => {
    if (!watermarkConfig?.protection?.dynamicWatermark || !clientData) {
      return watermarkConfig?.settings?.textWatermark || 'Jéssica Santos Fotografia'
    }

    const date = new Date().toLocaleDateString('pt-BR')
    return `${watermarkConfig.settings.textWatermark} • ${clientData.nome} • ${date}`
  }

  return (
    <div className={`protected-gallery ${protectionActive ? 'protection-active' : ''}`}>
      {/* Aviso de proteção */}
      {protectionActive && (
        <Alert className="mb-4">
          <Shield className="w-4 h-4" />
          <AlertDescription>
            Esta galeria está protegida contra cópias não autorizadas. 
            As imagens possuem marca d'água e proteções ativas.
          </AlertDescription>
        </Alert>
      )}

      {/* Overlay de proteção invisível */}
      {watermarkConfig?.protection?.overlayProtection && (
        <style jsx>{`
          .protected-gallery .image-container {
            position: relative;
          }
          .protected-gallery .image-container::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 5;
            background: transparent;
          }
        `}</style>
      )}

      {/* Conteúdo da galeria */}
      <div className="relative">
        {children}
        
        {/* Marca d'água dinâmica (se ativada) */}
        {watermarkConfig?.protection?.dynamicWatermark && (
          <div className="fixed bottom-4 right-4 text-xs text-muted-foreground opacity-50 pointer-events-none">
            {getDynamicWatermark()}
          </div>
        )}
      </div>

      {/* Contador de avisos (para debug) */}
      {warningCount > 0 && (
        <div className="fixed top-4 right-4 bg-red-500 text-white px-2 py-1 rounded text-xs">
          Avisos: {warningCount}
        </div>
      )}
    </div>
  )
}

export default ProtectedGallery
```

---

**💾 RESULTADO:** Sistema completo de marca d'água e proteção anti-cópia implementado!

