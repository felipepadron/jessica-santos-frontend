# 📸 SISTEMA DE GALERIA E SELEÇÃO DE FOTOS - JÉSSICA SANTOS

## 🎯 FUNCIONALIDADES DA GALERIA IMPLEMENTADAS

### 📱 GALERIA DE ENTREGA PARA CLIENTES
- **Galeria protegida** com senha personalizada
- **Visualização em alta qualidade** com zoom
- **Seleção de fotos favoritas** pelo cliente
- **Download individual ou em lote** das fotos
- **Comentários e feedback** em cada foto
- **Compartilhamento social** opcional
- **Expiração automática** da galeria
- **Notificações de acesso** para a fotógrafa

### 🎨 SISTEMA DE SELEÇÃO PARA EDIÇÃO
- **Interface de seleção** intuitiva para clientes
- **Limite de fotos** configurável por pacote
- **Preview de edição** com antes/depois
- **Aprovação de edições** pelo cliente
- **Versionamento** de fotos editadas
- **Histórico de alterações** solicitadas

## 🧩 COMPONENTES DA GALERIA

### 📸 GALERIA PRINCIPAL DO CLIENTE
```jsx
// src/components/gallery/ClientGallery.jsx
import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { 
  Heart, 
  Download, 
  Share2, 
  ZoomIn, 
  MessageCircle, 
  Star,
  Grid3X3,
  List,
  Filter,
  Search,
  CheckCircle,
  Clock,
  Eye
} from 'lucide-react'
import { formatarData } from '@/utils/helpers'
import { useGallery } from '@/hooks/useGallery'

const ClientGallery = ({ galleryId, clienteId, accessToken }) => {
  const { gallery, photos, loading, error, updatePhotoSelection, addComment, downloadPhotos } = useGallery(galleryId)
  const [selectedPhotos, setSelectedPhotos] = useState(new Set())
  const [viewMode, setViewMode] = useState('grid') // grid, list
  const [filterMode, setFilterMode] = useState('all') // all, selected, unselected
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedPhoto, setSelectedPhoto] = useState(null)
  const [showCommentDialog, setShowCommentDialog] = useState(false)
  const [comment, setComment] = useState('')
  const [showShareDialog, setShowShareDialog] = useState(false)

  useEffect(() => {
    if (gallery?.selectedPhotos) {
      setSelectedPhotos(new Set(gallery.selectedPhotos))
    }
  }, [gallery])

  const handlePhotoSelect = (photoId) => {
    const newSelected = new Set(selectedPhotos)
    
    if (newSelected.has(photoId)) {
      newSelected.delete(photoId)
    } else {
      // Verificar limite do pacote
      if (newSelected.size >= gallery.maxSelections) {
        alert(`Você pode selecionar no máximo ${gallery.maxSelections} fotos para edição.`)
        return
      }
      newSelected.add(photoId)
    }
    
    setSelectedPhotos(newSelected)
    updatePhotoSelection(photoId, newSelected.has(photoId))
  }

  const handleAddComment = async () => {
    if (comment.trim() && selectedPhoto) {
      await addComment(selectedPhoto.id, comment)
      setComment('')
      setShowCommentDialog(false)
    }
  }

  const handleDownloadSelected = () => {
    const photosToDownload = Array.from(selectedPhotos)
    downloadPhotos(photosToDownload)
  }

  const handleDownloadAll = () => {
    const allPhotoIds = photos.map(p => p.id)
    downloadPhotos(allPhotoIds)
  }

  const filteredPhotos = photos.filter(photo => {
    // Filtro por busca
    if (searchTerm && !photo.name.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false
    }
    
    // Filtro por seleção
    if (filterMode === 'selected' && !selectedPhotos.has(photo.id)) {
      return false
    }
    if (filterMode === 'unselected' && selectedPhotos.has(photo.id)) {
      return false
    }
    
    return true
  })

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Carregando galeria...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <Alert className="m-4">
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      {/* Header da Galeria */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gradient">
                {gallery.title}
              </h1>
              <p className="text-muted-foreground mt-1">
                Ensaio realizado em {formatarData(gallery.shootDate)}
              </p>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="flex items-center space-x-1">
                <Eye className="w-3 h-3" />
                <span>{gallery.totalPhotos} fotos</span>
              </Badge>
              
              <Badge variant="default" className="flex items-center space-x-1">
                <CheckCircle className="w-3 h-3" />
                <span>{selectedPhotos.size}/{gallery.maxSelections} selecionadas</span>
              </Badge>
              
              {gallery.expiresAt && (
                <Badge variant="destructive" className="flex items-center space-x-1">
                  <Clock className="w-3 h-3" />
                  <span>Expira em {formatarData(gallery.expiresAt)}</span>
                </Badge>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Instruções */}
      <div className="max-w-7xl mx-auto px-4 py-4">
        <Alert>
          <Star className="w-4 h-4" />
          <AlertDescription>
            <strong>Como usar:</strong> Clique nas fotos para selecioná-las para edição. 
            Você pode escolher até {gallery.maxSelections} fotos. 
            Use o coração para marcar suas favoritas e adicione comentários se desejar algum ajuste específico.
          </AlertDescription>
        </Alert>
      </div>

      {/* Controles */}
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          {/* Busca */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Buscar fotos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Filtros e Visualização */}
          <div className="flex items-center space-x-4">
            <Tabs value={filterMode} onValueChange={setFilterMode}>
              <TabsList>
                <TabsTrigger value="all">Todas</TabsTrigger>
                <TabsTrigger value="selected">Selecionadas</TabsTrigger>
                <TabsTrigger value="unselected">Não selecionadas</TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="flex items-center space-x-2">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('grid')}
              >
                <Grid3X3 className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('list')}
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Ações */}
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              onClick={handleDownloadSelected}
              disabled={selectedPhotos.size === 0}
              className="flex items-center space-x-2"
            >
              <Download className="w-4 h-4" />
              <span>Baixar Selecionadas</span>
            </Button>
            
            <Button
              onClick={handleDownloadAll}
              className="flex items-center space-x-2"
            >
              <Download className="w-4 h-4" />
              <span>Baixar Todas</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Galeria */}
      <div className="max-w-7xl mx-auto px-4 pb-8">
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {filteredPhotos.map((photo) => (
              <PhotoCard
                key={photo.id}
                photo={photo}
                isSelected={selectedPhotos.has(photo.id)}
                onSelect={() => handlePhotoSelect(photo.id)}
                onView={() => setSelectedPhoto(photo)}
                onComment={() => {
                  setSelectedPhoto(photo)
                  setShowCommentDialog(true)
                }}
              />
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredPhotos.map((photo) => (
              <PhotoListItem
                key={photo.id}
                photo={photo}
                isSelected={selectedPhotos.has(photo.id)}
                onSelect={() => handlePhotoSelect(photo.id)}
                onView={() => setSelectedPhoto(photo)}
                onComment={() => {
                  setSelectedPhoto(photo)
                  setShowCommentDialog(true)
                }}
              />
            ))}
          </div>
        )}
      </div>

      {/* Modal de Visualização */}
      {selectedPhoto && (
        <PhotoViewModal
          photo={selectedPhoto}
          isOpen={!!selectedPhoto}
          onClose={() => setSelectedPhoto(null)}
          isSelected={selectedPhotos.has(selectedPhoto.id)}
          onSelect={() => handlePhotoSelect(selectedPhoto.id)}
        />
      )}

      {/* Modal de Comentário */}
      <Dialog open={showCommentDialog} onOpenChange={setShowCommentDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adicionar Comentário</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Adicione um comentário sobre esta foto. Descreva qualquer ajuste específico que gostaria.
            </p>
            <Textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Ex: Gostaria que clareasse um pouco o rosto..."
              rows={4}
            />
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowCommentDialog(false)}>
                Cancelar
              </Button>
              <Button onClick={handleAddComment}>
                Adicionar Comentário
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Resumo da Seleção */}
      {selectedPhotos.size > 0 && (
        <div className="fixed bottom-4 right-4 bg-white rounded-lg shadow-lg border p-4 max-w-sm">
          <h3 className="font-semibold mb-2">Resumo da Seleção</h3>
          <p className="text-sm text-muted-foreground mb-3">
            {selectedPhotos.size} de {gallery.maxSelections} fotos selecionadas para edição
          </p>
          <div className="flex space-x-2">
            <Button size="sm" onClick={handleDownloadSelected} className="flex-1">
              Baixar Selecionadas
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

// Componente de Card da Foto
const PhotoCard = ({ photo, isSelected, onSelect, onView, onComment }) => {
  const [isFavorite, setIsFavorite] = useState(photo.isFavorite || false)

  return (
    <Card className={`group cursor-pointer transition-all hover:shadow-lg ${
      isSelected ? 'ring-2 ring-primary shadow-lg' : ''
    }`}>
      <CardContent className="p-0 relative">
        <div className="aspect-square overflow-hidden rounded-t-lg">
          <img
            src={photo.thumbnailUrl}
            alt={photo.name}
            className="w-full h-full object-cover transition-transform group-hover:scale-105"
            onClick={onView}
          />
        </div>
        
        {/* Overlay com controles */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all rounded-t-lg">
          <div className="absolute top-2 right-2 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              size="sm"
              variant="secondary"
              className="w-8 h-8 p-0"
              onClick={(e) => {
                e.stopPropagation()
                onView()
              }}
            >
              <ZoomIn className="w-4 h-4" />
            </Button>
            
            <Button
              size="sm"
              variant="secondary"
              className="w-8 h-8 p-0"
              onClick={(e) => {
                e.stopPropagation()
                setIsFavorite(!isFavorite)
              }}
            >
              <Heart className={`w-4 h-4 ${isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
            </Button>
          </div>
          
          <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              size="sm"
              variant="secondary"
              className="w-8 h-8 p-0"
              onClick={(e) => {
                e.stopPropagation()
                onComment()
              }}
            >
              <MessageCircle className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Indicador de seleção */}
        <div className="absolute top-2 left-2">
          <Button
            size="sm"
            variant={isSelected ? "default" : "secondary"}
            className="w-8 h-8 p-0"
            onClick={(e) => {
              e.stopPropagation()
              onSelect()
            }}
          >
            <CheckCircle className="w-4 h-4" />
          </Button>
        </div>

        {/* Info da foto */}
        <div className="p-3">
          <p className="text-xs text-muted-foreground truncate">
            {photo.name}
          </p>
          {photo.comments && photo.comments.length > 0 && (
            <div className="flex items-center space-x-1 mt-1">
              <MessageCircle className="w-3 h-3 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">
                {photo.comments.length} comentário(s)
              </span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

// Componente de Item da Lista
const PhotoListItem = ({ photo, isSelected, onSelect, onView, onComment }) => {
  return (
    <Card className={`transition-all hover:shadow-md ${
      isSelected ? 'ring-2 ring-primary' : ''
    }`}>
      <CardContent className="p-4">
        <div className="flex items-center space-x-4">
          <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
            <img
              src={photo.thumbnailUrl}
              alt={photo.name}
              className="w-full h-full object-cover cursor-pointer hover:scale-105 transition-transform"
              onClick={onView}
            />
          </div>
          
          <div className="flex-1">
            <h3 className="font-medium">{photo.name}</h3>
            <p className="text-sm text-muted-foreground">
              {photo.size} • {photo.dimensions}
            </p>
            {photo.comments && photo.comments.length > 0 && (
              <p className="text-xs text-muted-foreground mt-1">
                {photo.comments.length} comentário(s)
              </p>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant={isSelected ? "default" : "outline"}
              size="sm"
              onClick={onSelect}
              className="flex items-center space-x-1"
            >
              <CheckCircle className="w-4 h-4" />
              <span>{isSelected ? 'Selecionada' : 'Selecionar'}</span>
            </Button>
            
            <Button variant="outline" size="sm" onClick={onComment}>
              <MessageCircle className="w-4 h-4" />
            </Button>
            
            <Button variant="outline" size="sm" onClick={onView}>
              <ZoomIn className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// Modal de Visualização da Foto
const PhotoViewModal = ({ photo, isOpen, onClose, isSelected, onSelect }) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] p-0">
        <div className="relative">
          <img
            src={photo.fullUrl}
            alt={photo.name}
            className="w-full h-auto max-h-[80vh] object-contain"
          />
          
          <div className="absolute top-4 right-4 flex space-x-2">
            <Button
              variant={isSelected ? "default" : "secondary"}
              size="sm"
              onClick={onSelect}
              className="flex items-center space-x-1"
            >
              <CheckCircle className="w-4 h-4" />
              <span>{isSelected ? 'Selecionada' : 'Selecionar'}</span>
            </Button>
          </div>
          
          <div className="p-4 bg-white">
            <h3 className="font-medium">{photo.name}</h3>
            <p className="text-sm text-muted-foreground">
              {photo.size} • {photo.dimensions}
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export default ClientGallery
```

### 🎨 PAINEL DE GESTÃO DE GALERIAS (ADMIN)
```jsx
// src/components/gallery/GalleryManager.jsx
import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Progress } from '@/components/ui/progress'
import { 
  Upload, 
  FolderPlus, 
  Share2, 
  Eye, 
  Download, 
  Trash2,
  Settings,
  Users,
  Calendar,
  Image,
  Link,
  Copy,
  Send
} from 'lucide-react'
import { formatarData, formatarMoeda } from '@/utils/helpers'
import { useGalleryManager } from '@/hooks/useGalleryManager'

const GalleryManager = () => {
  const { galleries, createGallery, uploadPhotos, updateGallery, deleteGallery, getGalleryStats } = useGalleryManager()
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [showUploadDialog, setShowUploadDialog] = useState(false)
  const [selectedGallery, setSelectedGallery] = useState(null)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [newGallery, setNewGallery] = useState({
    title: '',
    clienteId: '',
    shootDate: '',
    maxSelections: 15,
    expiresAt: '',
    password: '',
    description: ''
  })

  const handleCreateGallery = async () => {
    try {
      const gallery = await createGallery(newGallery)
      setShowCreateDialog(false)
      setNewGallery({
        title: '',
        clienteId: '',
        shootDate: '',
        maxSelections: 15,
        expiresAt: '',
        password: '',
        description: ''
      })
    } catch (error) {
      console.error('Erro ao criar galeria:', error)
    }
  }

  const handleUploadPhotos = async (files) => {
    if (!selectedGallery) return

    try {
      await uploadPhotos(selectedGallery.id, files, (progress) => {
        setUploadProgress(progress)
      })
      setShowUploadDialog(false)
      setUploadProgress(0)
    } catch (error) {
      console.error('Erro ao fazer upload:', error)
    }
  }

  const generateGalleryLink = (gallery) => {
    return `${window.location.origin}/galeria/${gallery.id}?token=${gallery.accessToken}`
  }

  const copyGalleryLink = (gallery) => {
    const link = generateGalleryLink(gallery)
    navigator.clipboard.writeText(link)
    // Mostrar toast de sucesso
  }

  const sendGalleryToClient = async (gallery) => {
    // Enviar galeria por WhatsApp/Email
    const link = generateGalleryLink(gallery)
    const message = `
🎉 Suas fotos estão prontas!

Olá! Seu ensaio ficou lindo e as fotos já estão disponíveis para visualização e seleção.

🔗 Link da galeria: ${link}
🔒 Senha: ${gallery.password}

📋 Instruções:
• Você pode selecionar até ${gallery.maxSelections} fotos para edição
• Clique nas fotos para selecioná-las
• Use o coração para marcar suas favoritas
• Adicione comentários se quiser algum ajuste específico

⏰ A galeria fica disponível até ${formatarData(gallery.expiresAt)}

Qualquer dúvida, estou aqui! 💕

Jéssica Santos Fotografia
    `
    
    // Aqui integraria com WhatsApp/Email
    console.log('Enviando galeria:', message)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Gestão de Galerias</h1>
          <p className="text-muted-foreground">
            Gerencie galerias de entrega e seleção de fotos
          </p>
        </div>
        
        <Button onClick={() => setShowCreateDialog(true)} className="flex items-center space-x-2">
          <FolderPlus className="w-4 h-4" />
          <span>Nova Galeria</span>
        </Button>
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <FolderPlus className="w-5 h-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Total de Galerias</p>
                <p className="text-2xl font-bold">{galleries.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Image className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-sm text-muted-foreground">Fotos Enviadas</p>
                <p className="text-2xl font-bold">
                  {galleries.reduce((sum, g) => sum + (g.totalPhotos || 0), 0)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Eye className="w-5 h-5 text-green-500" />
              <div>
                <p className="text-sm text-muted-foreground">Galerias Ativas</p>
                <p className="text-2xl font-bold">
                  {galleries.filter(g => new Date(g.expiresAt) > new Date()).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5 text-orange-500" />
              <div>
                <p className="text-sm text-muted-foreground">Seleções Pendentes</p>
                <p className="text-2xl font-bold">
                  {galleries.filter(g => g.status === 'pending_selection').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Lista de Galerias */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {galleries.map((gallery) => (
          <GalleryCard
            key={gallery.id}
            gallery={gallery}
            onUpload={() => {
              setSelectedGallery(gallery)
              setShowUploadDialog(true)
            }}
            onCopyLink={() => copyGalleryLink(gallery)}
            onSendToClient={() => sendGalleryToClient(gallery)}
            onEdit={() => {
              // Abrir modal de edição
            }}
            onDelete={() => deleteGallery(gallery.id)}
          />
        ))}
      </div>

      {/* Modal de Criação */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Nova Galeria</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="title">Título da Galeria</Label>
                <Input
                  id="title"
                  value={newGallery.title}
                  onChange={(e) => setNewGallery(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Ensaio da Maria - Gestante"
                />
              </div>
              
              <div>
                <Label htmlFor="cliente">Cliente</Label>
                <Input
                  id="cliente"
                  value={newGallery.clienteId}
                  onChange={(e) => setNewGallery(prev => ({ ...prev, clienteId: e.target.value }))}
                  placeholder="ID ou nome do cliente"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="shoot-date">Data do Ensaio</Label>
                <Input
                  id="shoot-date"
                  type="date"
                  value={newGallery.shootDate}
                  onChange={(e) => setNewGallery(prev => ({ ...prev, shootDate: e.target.value }))}
                />
              </div>
              
              <div>
                <Label htmlFor="expires-at">Data de Expiração</Label>
                <Input
                  id="expires-at"
                  type="date"
                  value={newGallery.expiresAt}
                  onChange={(e) => setNewGallery(prev => ({ ...prev, expiresAt: e.target.value }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="max-selections">Máximo de Seleções</Label>
                <Input
                  id="max-selections"
                  type="number"
                  value={newGallery.maxSelections}
                  onChange={(e) => setNewGallery(prev => ({ ...prev, maxSelections: Number(e.target.value) }))}
                  placeholder="15"
                />
              </div>
              
              <div>
                <Label htmlFor="password">Senha de Acesso</Label>
                <Input
                  id="password"
                  value={newGallery.password}
                  onChange={(e) => setNewGallery(prev => ({ ...prev, password: e.target.value }))}
                  placeholder="Senha personalizada"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={newGallery.description}
                onChange={(e) => setNewGallery(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Descrição opcional da galeria..."
                rows={3}
              />
            </div>

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                Cancelar
              </Button>
              <Button onClick={handleCreateGallery}>
                Criar Galeria
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de Upload */}
      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Upload de Fotos</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="border-2 border-dashed border-muted rounded-lg p-8 text-center">
              <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-lg font-medium mb-2">Arraste as fotos aqui</p>
              <p className="text-sm text-muted-foreground mb-4">
                ou clique para selecionar arquivos
              </p>
              <Button variant="outline">
                Selecionar Fotos
              </Button>
            </div>
            
            {uploadProgress > 0 && (
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Enviando fotos...</span>
                  <span>{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} />
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Componente de Card da Galeria
const GalleryCard = ({ gallery, onUpload, onCopyLink, onSendToClient, onEdit, onDelete }) => {
  const isExpired = new Date(gallery.expiresAt) < new Date()
  const isActive = gallery.status === 'active'
  
  return (
    <Card className={`transition-all hover:shadow-lg ${isExpired ? 'opacity-75' : ''}`}>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">{gallery.title}</CardTitle>
            <p className="text-sm text-muted-foreground">
              Cliente: {gallery.clienteName}
            </p>
          </div>
          
          <div className="flex items-center space-x-1">
            <Badge variant={isActive ? 'default' : isExpired ? 'destructive' : 'secondary'}>
              {isExpired ? 'Expirada' : isActive ? 'Ativa' : 'Pendente'}
            </Badge>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Fotos</p>
            <p className="font-medium">{gallery.totalPhotos || 0}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Selecionadas</p>
            <p className="font-medium">{gallery.selectedPhotos?.length || 0}/{gallery.maxSelections}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Ensaio</p>
            <p className="font-medium">{formatarData(gallery.shootDate)}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Expira</p>
            <p className="font-medium">{formatarData(gallery.expiresAt)}</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="outline" onClick={onUpload}>
            <Upload className="w-3 h-3 mr-1" />
            Upload
          </Button>
          
          <Button size="sm" variant="outline" onClick={onCopyLink}>
            <Copy className="w-3 h-3 mr-1" />
            Copiar Link
          </Button>
          
          <Button size="sm" variant="outline" onClick={onSendToClient}>
            <Send className="w-3 h-3 mr-1" />
            Enviar
          </Button>
          
          <Button size="sm" variant="outline" onClick={onEdit}>
            <Settings className="w-3 h-3 mr-1" />
            Editar
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

export default GalleryManager
```

---

**💾 RESULTADO:** Sistema completo de galeria de entrega e seleção de fotos para clientes!

