# 🔧 SISTEMA DE CONFIGURAÇÕES E GESTÃO - JÉSSICA SANTOS ERP

## 🎯 MÓDULOS DE CONFIGURAÇÃO IMPLEMENTADOS

### ⚙️ 1. WIZARD DE SETUP INICIAL
Sistema completo de configuração inicial com interface visual para todas as integrações.

### 👥 2. GESTÃO DE USUÁRIOS
Sistema completo de usuários, perfis e permissões.

### 🎨 3. PREFERÊNCIAS DO SISTEMA
Configurações de aparência, comportamento e personalização.

### 🔗 4. GESTÃO DE INTEGRAÇÕES
Configuração e monitoramento de todas as integrações externas.

### 📊 5. CONFIGURAÇÕES DE NEGÓCIO
Configurações específicas do negócio da Jéssica Santos.

## 🧩 COMPONENTES DE CONFIGURAÇÃO

### 🚀 WIZARD DE SETUP INICIAL
```jsx
// src/components/setup/SetupWizard.jsx
import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { CheckCircle, AlertTriangle, Settings, ArrowRight, ArrowLeft } from 'lucide-react'
import { BusinessSetup } from './BusinessSetup'
import { IntegrationsSetup } from './IntegrationsSetup'
import { UserSetup } from './UserSetup'
import { PreferencesSetup } from './PreferencesSetup'
import { FinalSetup } from './FinalSetup'

const SetupWizard = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0)
  const [setupData, setSetupData] = useState({
    business: {},
    integrations: {},
    user: {},
    preferences: {}
  })
  const [completedSteps, setCompletedSteps] = useState(new Set())

  const steps = [
    {
      id: 'business',
      title: 'Configurações do Negócio',
      description: 'Informações básicas da Jéssica Santos Fotografia',
      component: BusinessSetup,
      required: true
    },
    {
      id: 'user',
      title: 'Usuário Administrador',
      description: 'Criar conta de administrador do sistema',
      component: UserSetup,
      required: true
    },
    {
      id: 'integrations',
      title: 'Integrações',
      description: 'WhatsApp, Email, Analytics e Pagamentos',
      component: IntegrationsSetup,
      required: false
    },
    {
      id: 'preferences',
      title: 'Preferências',
      description: 'Aparência e comportamento do sistema',
      component: PreferencesSetup,
      required: false
    },
    {
      id: 'final',
      title: 'Finalização',
      description: 'Revisão e ativação do sistema',
      component: FinalSetup,
      required: true
    }
  ]

  const currentStepData = steps[currentStep]
  const progress = ((currentStep + 1) / steps.length) * 100

  const handleStepComplete = (stepId, data) => {
    setSetupData(prev => ({
      ...prev,
      [stepId]: data
    }))
    setCompletedSteps(prev => new Set([...prev, stepId]))
  }

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleFinish = () => {
    // Salvar configurações finais
    localStorage.setItem('jessica_erp_setup_complete', 'true')
    localStorage.setItem('jessica_erp_config', JSON.stringify(setupData))
    onComplete(setupData)
  }

  const isStepCompleted = (stepId) => completedSteps.has(stepId)
  const canProceed = isStepCompleted(currentStepData.id) || !currentStepData.required

  const CurrentComponent = currentStepData.component

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gradient mb-2">
            Configuração Inicial
          </h1>
          <p className="text-muted-foreground">
            Vamos configurar seu sistema ERP da Jéssica Santos Fotografia
          </p>
        </div>

        {/* Progress */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium">
                Etapa {currentStep + 1} de {steps.length}
              </span>
              <span className="text-sm text-muted-foreground">
                {Math.round(progress)}% concluído
              </span>
            </div>
            <Progress value={progress} className="mb-4" />
            
            {/* Steps indicator */}
            <div className="flex justify-between">
              {steps.map((step, index) => (
                <div key={step.id} className="flex flex-col items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    index === currentStep 
                      ? 'bg-primary text-primary-foreground' 
                      : isStepCompleted(step.id)
                      ? 'bg-green-500 text-white'
                      : 'bg-muted text-muted-foreground'
                  }`}>
                    {isStepCompleted(step.id) ? (
                      <CheckCircle className="w-4 h-4" />
                    ) : (
                      index + 1
                    )}
                  </div>
                  <span className="text-xs mt-1 text-center max-w-20">
                    {step.title}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Current Step */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="w-5 h-5" />
                  <span>{currentStepData.title}</span>
                  {currentStepData.required && (
                    <Badge variant="destructive" className="text-xs">
                      Obrigatório
                    </Badge>
                  )}
                </CardTitle>
                <p className="text-muted-foreground mt-1">
                  {currentStepData.description}
                </p>
              </div>
              
              {isStepCompleted(currentStepData.id) && (
                <CheckCircle className="w-6 h-6 text-green-500" />
              )}
            </div>
          </CardHeader>
          
          <CardContent>
            <CurrentComponent
              data={setupData[currentStepData.id]}
              onComplete={(data) => handleStepComplete(currentStepData.id, data)}
              setupData={setupData}
            />
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentStep === 0}
            className="flex items-center space-x-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Anterior</span>
          </Button>

          {currentStep === steps.length - 1 ? (
            <Button
              onClick={handleFinish}
              disabled={!canProceed}
              className="flex items-center space-x-2"
            >
              <CheckCircle className="w-4 h-4" />
              <span>Finalizar Configuração</span>
            </Button>
          ) : (
            <Button
              onClick={handleNext}
              disabled={!canProceed}
              className="flex items-center space-x-2"
            >
              <span>Próximo</span>
              <ArrowRight className="w-4 h-4" />
            </Button>
          )}
        </div>

        {/* Warning for required steps */}
        {currentStepData.required && !isStepCompleted(currentStepData.id) && (
          <Alert className="mt-4">
            <AlertTriangle className="w-4 h-4" />
            <AlertDescription>
              Esta etapa é obrigatória para o funcionamento do sistema.
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  )
}

export default SetupWizard
```

### 🏢 CONFIGURAÇÕES DE NEGÓCIO
```jsx
// src/components/setup/BusinessSetup.jsx
import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Building, MapPin, Phone, Mail, Clock, DollarSign } from 'lucide-react'

const BusinessSetup = ({ data = {}, onComplete }) => {
  const [businessData, setBusinessData] = useState({
    nome: 'Jéssica Santos Fotografia',
    cnpj: '',
    endereco: 'Rua Luzia Maria Silva, 345 - Vila Mariana, SP',
    telefone: '(11) 99999-9999',
    email: 'jessica@jessicasantos.com.br',
    instagram: '@jessicasantos.foto',
    site: 'https://jessicasantos.com.br',
    horarioFuncionamento: {
      inicio: '10:00',
      fim: '18:00',
      diasSemana: ['1', '2', '3', '4', '5', '6'] // Segunda a Sábado
    },
    configuracoesPagamento: {
      sinalPadrao: 300,
      parcelasMaximas: 3,
      multaAtraso: 2
    },
    configuracaoAgendamento: {
      antecedenciaMinima: '24h',
      antecedenciaMaxima: '90d',
      duracaoSessaoPadrao: '2h'
    },
    ...data
  })

  const [isValid, setIsValid] = useState(false)

  useEffect(() => {
    const required = ['nome', 'telefone', 'email']
    const valid = required.every(field => businessData[field]?.trim())
    setIsValid(valid)
    
    if (valid) {
      onComplete(businessData)
    }
  }, [businessData, onComplete])

  const handleChange = (field, value) => {
    setBusinessData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleNestedChange = (parent, field, value) => {
    setBusinessData(prev => ({
      ...prev,
      [parent]: {
        ...prev[parent],
        [field]: value
      }
    }))
  }

  const diasSemana = [
    { value: '0', label: 'Domingo' },
    { value: '1', label: 'Segunda' },
    { value: '2', label: 'Terça' },
    { value: '3', label: 'Quarta' },
    { value: '4', label: 'Quinta' },
    { value: '5', label: 'Sexta' },
    { value: '6', label: 'Sábado' }
  ]

  return (
    <div className="space-y-6">
      {/* Informações Básicas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Building className="w-5 h-5" />
            <span>Informações da Empresa</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="nome">Nome da Empresa *</Label>
              <Input
                id="nome"
                value={businessData.nome}
                onChange={(e) => handleChange('nome', e.target.value)}
                placeholder="Jéssica Santos Fotografia"
              />
            </div>
            <div>
              <Label htmlFor="cnpj">CNPJ</Label>
              <Input
                id="cnpj"
                value={businessData.cnpj}
                onChange={(e) => handleChange('cnpj', e.target.value)}
                placeholder="00.000.000/0001-00"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="endereco">Endereço</Label>
            <Textarea
              id="endereco"
              value={businessData.endereco}
              onChange={(e) => handleChange('endereco', e.target.value)}
              placeholder="Endereço completo do estúdio"
              rows={2}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="telefone">Telefone *</Label>
              <Input
                id="telefone"
                value={businessData.telefone}
                onChange={(e) => handleChange('telefone', e.target.value)}
                placeholder="(11) 99999-9999"
              />
            </div>
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={businessData.email}
                onChange={(e) => handleChange('email', e.target.value)}
                placeholder="jessica@jessicasantos.com.br"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="instagram">Instagram</Label>
              <Input
                id="instagram"
                value={businessData.instagram}
                onChange={(e) => handleChange('instagram', e.target.value)}
                placeholder="@jessicasantos.foto"
              />
            </div>
            <div>
              <Label htmlFor="site">Site</Label>
              <Input
                id="site"
                value={businessData.site}
                onChange={(e) => handleChange('site', e.target.value)}
                placeholder="https://jessicasantos.com.br"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Horário de Funcionamento */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Clock className="w-5 h-5" />
            <span>Horário de Funcionamento</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="horario-inicio">Horário de Início</Label>
              <Input
                id="horario-inicio"
                type="time"
                value={businessData.horarioFuncionamento.inicio}
                onChange={(e) => handleNestedChange('horarioFuncionamento', 'inicio', e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="horario-fim">Horário de Término</Label>
              <Input
                id="horario-fim"
                type="time"
                value={businessData.horarioFuncionamento.fim}
                onChange={(e) => handleNestedChange('horarioFuncionamento', 'fim', e.target.value)}
              />
            </div>
          </div>

          <div>
            <Label>Dias de Funcionamento</Label>
            <div className="flex flex-wrap gap-2 mt-2">
              {diasSemana.map(dia => (
                <Badge
                  key={dia.value}
                  variant={businessData.horarioFuncionamento.diasSemana.includes(dia.value) ? 'default' : 'outline'}
                  className="cursor-pointer"
                  onClick={() => {
                    const dias = businessData.horarioFuncionamento.diasSemana
                    const newDias = dias.includes(dia.value)
                      ? dias.filter(d => d !== dia.value)
                      : [...dias, dia.value]
                    handleNestedChange('horarioFuncionamento', 'diasSemana', newDias)
                  }}
                >
                  {dia.label}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Configurações Financeiras */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <DollarSign className="w-5 h-5" />
            <span>Configurações Financeiras</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="sinal-padrao">Sinal Padrão (R$)</Label>
              <Input
                id="sinal-padrao"
                type="number"
                value={businessData.configuracoesPagamento.sinalPadrao}
                onChange={(e) => handleNestedChange('configuracoesPagamento', 'sinalPadrao', Number(e.target.value))}
                placeholder="300"
              />
            </div>
            <div>
              <Label htmlFor="parcelas-maximas">Parcelas Máximas</Label>
              <Select
                value={businessData.configuracoesPagamento.parcelasMaximas.toString()}
                onValueChange={(value) => handleNestedChange('configuracoesPagamento', 'parcelasMaximas', Number(value))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1x (à vista)</SelectItem>
                  <SelectItem value="2">2x sem juros</SelectItem>
                  <SelectItem value="3">3x sem juros</SelectItem>
                  <SelectItem value="4">4x sem juros</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="multa-atraso">Multa por Atraso (%)</Label>
              <Input
                id="multa-atraso"
                type="number"
                value={businessData.configuracoesPagamento.multaAtraso}
                onChange={(e) => handleNestedChange('configuracoesPagamento', 'multaAtraso', Number(e.target.value))}
                placeholder="2"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Status */}
      <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
        <span className="text-sm">
          {isValid ? '✅ Configurações válidas' : '⚠️ Preencha os campos obrigatórios'}
        </span>
        {isValid && (
          <Badge variant="default">Etapa Concluída</Badge>
        )}
      </div>
    </div>
  )
}

export default BusinessSetup
```

### 🔗 CONFIGURAÇÃO DE INTEGRAÇÕES
```jsx
// src/components/setup/IntegrationsSetup.jsx
import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  MessageCircle, 
  Mail, 
  BarChart3, 
  CreditCard, 
  AlertTriangle, 
  CheckCircle,
  ExternalLink,
  Info
} from 'lucide-react'

const IntegrationsSetup = ({ data = {}, onComplete }) => {
  const [integrations, setIntegrations] = useState({
    whatsapp: {
      enabled: false,
      token: '',
      phoneId: '',
      verifyToken: '',
      ...data.whatsapp
    },
    email: {
      enabled: false,
      service: 'gmail',
      user: '',
      password: '',
      ...data.email
    },
    analytics: {
      enabled: false,
      gaId: '',
      fbPixelId: '',
      ...data.analytics
    },
    payments: {
      enabled: false,
      stripePublic: '',
      stripeSecret: '',
      ...data.payments
    },
    ...data
  })

  const [testResults, setTestResults] = useState({})

  useEffect(() => {
    onComplete(integrations)
  }, [integrations, onComplete])

  const handleToggle = (integration, enabled) => {
    setIntegrations(prev => ({
      ...prev,
      [integration]: {
        ...prev[integration],
        enabled
      }
    }))
  }

  const handleChange = (integration, field, value) => {
    setIntegrations(prev => ({
      ...prev,
      [integration]: {
        ...prev[integration],
        [field]: value
      }
    }))
  }

  const testIntegration = async (integration) => {
    setTestResults(prev => ({ ...prev, [integration]: 'testing' }))
    
    // Simular teste de integração
    setTimeout(() => {
      const success = Math.random() > 0.3 // 70% de chance de sucesso
      setTestResults(prev => ({ 
        ...prev, 
        [integration]: success ? 'success' : 'error' 
      }))
    }, 2000)
  }

  const getIntegrationStatus = (integration) => {
    if (!integrations[integration].enabled) return 'disabled'
    if (testResults[integration] === 'testing') return 'testing'
    if (testResults[integration] === 'success') return 'success'
    if (testResults[integration] === 'error') return 'error'
    return 'pending'
  }

  const getStatusBadge = (status) => {
    const variants = {
      disabled: { variant: 'secondary', text: 'Desabilitado' },
      pending: { variant: 'outline', text: 'Pendente' },
      testing: { variant: 'default', text: 'Testando...' },
      success: { variant: 'default', text: 'Conectado', className: 'bg-green-500' },
      error: { variant: 'destructive', text: 'Erro' }
    }
    
    const config = variants[status]
    return (
      <Badge variant={config.variant} className={config.className}>
        {config.text}
      </Badge>
    )
  }

  const integrationImpacts = {
    whatsapp: {
      features: [
        'Confirmação automática de agendamentos',
        'Lembretes 24h antes do ensaio',
        'Notificação de entrega de fotos',
        'Suporte ao cliente via WhatsApp',
        'Marketing direto personalizado'
      ],
      impact: 'Alto - Comunicação com clientes será limitada'
    },
    email: {
      features: [
        'Envio de contratos por email',
        'Confirmações de agendamento',
        'Newsletters e campanhas',
        'Notificações do sistema',
        'Backup de comunicações'
      ],
      impact: 'Alto - Comunicação formal será limitada'
    },
    analytics: {
      features: [
        'Tracking de conversões',
        'Análise de comportamento do site',
        'ROI de campanhas de marketing',
        'Funil de vendas detalhado',
        'Relatórios de performance'
      ],
      impact: 'Médio - Perda de insights de marketing'
    },
    payments: {
      features: [
        'Pagamentos online via cartão',
        'Pagamentos via PIX',
        'Controle automático de recebimentos',
        'Relatórios financeiros detalhados',
        'Integração com contratos'
      ],
      impact: 'Médio - Pagamentos manuais apenas'
    }
  }

  return (
    <div className="space-y-6">
      <Alert>
        <Info className="w-4 h-4" />
        <AlertDescription>
          As integrações são opcionais, mas cada uma oferece funcionalidades importantes. 
          Você pode configurá-las agora ou depois nas configurações do sistema.
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="whatsapp" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="whatsapp" className="flex items-center space-x-2">
            <MessageCircle className="w-4 h-4" />
            <span>WhatsApp</span>
          </TabsTrigger>
          <TabsTrigger value="email" className="flex items-center space-x-2">
            <Mail className="w-4 h-4" />
            <span>Email</span>
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center space-x-2">
            <BarChart3 className="w-4 h-4" />
            <span>Analytics</span>
          </TabsTrigger>
          <TabsTrigger value="payments" className="flex items-center space-x-2">
            <CreditCard className="w-4 h-4" />
            <span>Pagamentos</span>
          </TabsTrigger>
        </TabsList>

        {/* WhatsApp */}
        <TabsContent value="whatsapp">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  <MessageCircle className="w-5 h-5" />
                  <span>WhatsApp Business API</span>
                </CardTitle>
                <div className="flex items-center space-x-2">
                  {getStatusBadge(getIntegrationStatus('whatsapp'))}
                  <Switch
                    checked={integrations.whatsapp.enabled}
                    onCheckedChange={(enabled) => handleToggle('whatsapp', enabled)}
                  />
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {integrations.whatsapp.enabled ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="whatsapp-token">Access Token</Label>
                      <Input
                        id="whatsapp-token"
                        type="password"
                        value={integrations.whatsapp.token}
                        onChange={(e) => handleChange('whatsapp', 'token', e.target.value)}
                        placeholder="EAAxxxxxxxxxx..."
                      />
                    </div>
                    <div>
                      <Label htmlFor="whatsapp-phone">Phone Number ID</Label>
                      <Input
                        id="whatsapp-phone"
                        value={integrations.whatsapp.phoneId}
                        onChange={(e) => handleChange('whatsapp', 'phoneId', e.target.value)}
                        placeholder="123456789012345"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="whatsapp-verify">Verify Token</Label>
                    <Input
                      id="whatsapp-verify"
                      value={integrations.whatsapp.verifyToken}
                      onChange={(e) => handleChange('whatsapp', 'verifyToken', e.target.value)}
                      placeholder="jessica_santos_verify_token"
                    />
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      onClick={() => testIntegration('whatsapp')}
                      disabled={testResults.whatsapp === 'testing'}
                    >
                      {testResults.whatsapp === 'testing' ? 'Testando...' : 'Testar Conexão'}
                    </Button>
                    <Button variant="outline" asChild>
                      <a href="https://developers.facebook.com/docs/whatsapp" target="_blank">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Documentação
                      </a>
                    </Button>
                  </div>
                </>
              ) : (
                <Alert>
                  <AlertTriangle className="w-4 h-4" />
                  <AlertDescription>
                    <strong>Funcionalidades perdidas sem WhatsApp:</strong>
                    <ul className="list-disc list-inside mt-2 space-y-1">
                      {integrationImpacts.whatsapp.features.map((feature, index) => (
                        <li key={index} className="text-sm">{feature}</li>
                      ))}
                    </ul>
                    <p className="mt-2 font-medium text-destructive">
                      {integrationImpacts.whatsapp.impact}
                    </p>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Email */}
        <TabsContent value="email">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  <Mail className="w-5 h-5" />
                  <span>Configuração de Email</span>
                </CardTitle>
                <div className="flex items-center space-x-2">
                  {getStatusBadge(getIntegrationStatus('email'))}
                  <Switch
                    checked={integrations.email.enabled}
                    onCheckedChange={(enabled) => handleToggle('email', enabled)}
                  />
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {integrations.email.enabled ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="email-user">Email</Label>
                      <Input
                        id="email-user"
                        type="email"
                        value={integrations.email.user}
                        onChange={(e) => handleChange('email', 'user', e.target.value)}
                        placeholder="atendimento@jessicasantos.com.br"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email-password">Senha de App</Label>
                      <Input
                        id="email-password"
                        type="password"
                        value={integrations.email.password}
                        onChange={(e) => handleChange('email', 'password', e.target.value)}
                        placeholder="Senha de app do Gmail"
                      />
                    </div>
                  </div>

                  <Alert>
                    <Info className="w-4 h-4" />
                    <AlertDescription>
                      Para Gmail, você precisa gerar uma "Senha de App" nas configurações de segurança da sua conta Google.
                    </AlertDescription>
                  </Alert>

                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      onClick={() => testIntegration('email')}
                      disabled={testResults.email === 'testing'}
                    >
                      {testResults.email === 'testing' ? 'Testando...' : 'Testar Envio'}
                    </Button>
                    <Button variant="outline" asChild>
                      <a href="https://support.google.com/accounts/answer/185833" target="_blank">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Como gerar senha de app
                      </a>
                    </Button>
                  </div>
                </>
              ) : (
                <Alert>
                  <AlertTriangle className="w-4 h-4" />
                  <AlertDescription>
                    <strong>Funcionalidades perdidas sem Email:</strong>
                    <ul className="list-disc list-inside mt-2 space-y-1">
                      {integrationImpacts.email.features.map((feature, index) => (
                        <li key={index} className="text-sm">{feature}</li>
                      ))}
                    </ul>
                    <p className="mt-2 font-medium text-destructive">
                      {integrationImpacts.email.impact}
                    </p>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics */}
        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="w-5 h-5" />
                  <span>Analytics e Tracking</span>
                </CardTitle>
                <div className="flex items-center space-x-2">
                  {getStatusBadge(getIntegrationStatus('analytics'))}
                  <Switch
                    checked={integrations.analytics.enabled}
                    onCheckedChange={(enabled) => handleToggle('analytics', enabled)}
                  />
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {integrations.analytics.enabled ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="ga-id">Google Analytics ID</Label>
                      <Input
                        id="ga-id"
                        value={integrations.analytics.gaId}
                        onChange={(e) => handleChange('analytics', 'gaId', e.target.value)}
                        placeholder="G-XXXXXXXXXX"
                      />
                    </div>
                    <div>
                      <Label htmlFor="fb-pixel">Facebook Pixel ID</Label>
                      <Input
                        id="fb-pixel"
                        value={integrations.analytics.fbPixelId}
                        onChange={(e) => handleChange('analytics', 'fbPixelId', e.target.value)}
                        placeholder="123456789012345"
                      />
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      onClick={() => testIntegration('analytics')}
                      disabled={testResults.analytics === 'testing'}
                    >
                      {testResults.analytics === 'testing' ? 'Testando...' : 'Testar Tracking'}
                    </Button>
                    <Button variant="outline" asChild>
                      <a href="https://analytics.google.com/" target="_blank">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Google Analytics
                      </a>
                    </Button>
                  </div>
                </>
              ) : (
                <Alert>
                  <AlertTriangle className="w-4 h-4" />
                  <AlertDescription>
                    <strong>Funcionalidades perdidas sem Analytics:</strong>
                    <ul className="list-disc list-inside mt-2 space-y-1">
                      {integrationImpacts.analytics.features.map((feature, index) => (
                        <li key={index} className="text-sm">{feature}</li>
                      ))}
                    </ul>
                    <p className="mt-2 font-medium text-orange-600">
                      {integrationImpacts.analytics.impact}
                    </p>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payments */}
        <TabsContent value="payments">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  <CreditCard className="w-5 h-5" />
                  <span>Pagamentos Online</span>
                </CardTitle>
                <div className="flex items-center space-x-2">
                  {getStatusBadge(getIntegrationStatus('payments'))}
                  <Switch
                    checked={integrations.payments.enabled}
                    onCheckedChange={(enabled) => handleToggle('payments', enabled)}
                  />
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              {integrations.payments.enabled ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="stripe-public">Stripe Publishable Key</Label>
                      <Input
                        id="stripe-public"
                        value={integrations.payments.stripePublic}
                        onChange={(e) => handleChange('payments', 'stripePublic', e.target.value)}
                        placeholder="pk_test_..."
                      />
                    </div>
                    <div>
                      <Label htmlFor="stripe-secret">Stripe Secret Key</Label>
                      <Input
                        id="stripe-secret"
                        type="password"
                        value={integrations.payments.stripeSecret}
                        onChange={(e) => handleChange('payments', 'stripeSecret', e.target.value)}
                        placeholder="sk_test_..."
                      />
                    </div>
                  </div>

                  <Alert>
                    <Info className="w-4 h-4" />
                    <AlertDescription>
                      Use as chaves de teste durante o desenvolvimento. Troque pelas chaves de produção quando for ao ar.
                    </AlertDescription>
                  </Alert>

                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      onClick={() => testIntegration('payments')}
                      disabled={testResults.payments === 'testing'}
                    >
                      {testResults.payments === 'testing' ? 'Testando...' : 'Testar Conexão'}
                    </Button>
                    <Button variant="outline" asChild>
                      <a href="https://dashboard.stripe.com/" target="_blank">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Dashboard Stripe
                      </a>
                    </Button>
                  </div>
                </>
              ) : (
                <Alert>
                  <AlertTriangle className="w-4 h-4" />
                  <AlertDescription>
                    <strong>Funcionalidades perdidas sem Pagamentos:</strong>
                    <ul className="list-disc list-inside mt-2 space-y-1">
                      {integrationImpacts.payments.features.map((feature, index) => (
                        <li key={index} className="text-sm">{feature}</li>
                      ))}
                    </ul>
                    <p className="mt-2 font-medium text-orange-600">
                      {integrationImpacts.payments.impact}
                    </p>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Resumo das Integrações */}
      <Card>
        <CardHeader>
          <CardTitle>Resumo das Integrações</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Object.entries(integrations).map(([key, config]) => (
              <div key={key} className="text-center">
                <div className="mb-2">
                  {key === 'whatsapp' && <MessageCircle className="w-8 h-8 mx-auto" />}
                  {key === 'email' && <Mail className="w-8 h-8 mx-auto" />}
                  {key === 'analytics' && <BarChart3 className="w-8 h-8 mx-auto" />}
                  {key === 'payments' && <CreditCard className="w-8 h-8 mx-auto" />}
                </div>
                <p className="font-medium capitalize">{key}</p>
                {getStatusBadge(getIntegrationStatus(key))}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default IntegrationsSetup
```

---

**💾 RESULTADO:** Sistema completo de configuração inicial com wizard visual e alertas de impacto!

