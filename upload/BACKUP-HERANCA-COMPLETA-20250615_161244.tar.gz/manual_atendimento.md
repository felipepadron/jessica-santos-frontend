# Manual Completo de Atendimento - Jéssica Santos

## 📸 1. Serviços Oferecidos

A Jéssica oferece ensaios fotográficos e mentorias estratégicas voltadas ao público feminino.

### Ensaios Fotográficos:
- **Ensaio Essencial** – R$ 1.800 – 1h – 15 fotos editadas
- **Ensaio Intenso** – R$ 2.400 – 1h30 – 25 fotos + vídeo 30s
- **Ensaio Completo** – R$ 3.200 – 2h30 – 40 fotos + vídeo + kit especial

### Mentorias:
- **Mentoria Essencial** – R$ 950 – Sessão única 1h30
- **Mentoria Estratégica** – R$ 2.800 – 3 encontros quinzenais
- **Mentoria Transformadora** – R$ 4.800 – Programa de 6 encontros

## 🔁 2. Processo de Atendimento

1. Recepção da cliente com mensagem humanizada via WhatsApp ou Instagram
2. Identificação da demanda: ensaio, mentoria ou dúvida
3. Apresentação personalizada dos pacotes disponíveis
4. Envio de proposta em PDF ou mensagem com detalhes
5. Confirmação e agendamento via calendário
6. Pré-ensaio: envio de orientações + checklist personalizado
7. Dia do ensaio ou sessão: acolhimento emocional e experiência completa
8. Pós atendimento: envio do material + mensagem de carinho

## 📋 3. Políticas Comerciais

- O agendamento é confirmado mediante sinal de R$ 300, não reembolsável
- Cancelamentos com menos de 7 dias do ensaio implicam na perda do sinal
- Reagendamentos podem ser feitos com até 5 dias de antecedência
- Parcelamento possível via Pix ou crédito até 3x (juros à parte)
- O restante do valor deve ser quitado até a data do ensaio
- Em casos de força maior (doença, gestação de risco etc.), a cliente pode reagendar uma única vez sem custo

## 📞 4. Informações de Contato

- **WhatsApp:** (11) 9 9999-9999
- **E-mail:** atendimento@jessicasantosfotografia.com.br
- **Instagram:** @jessicasantos.foto
- **Estúdio:** Rua Luzia Maria Silva, 345 – Vila Mariana, São Paulo – SP

## ⏰ 5. Horários de Funcionamento

- **Segunda a Sexta:** 10h às 18h
- **Sábados:** 9h às 13h (mediante agendamento)
- **Sessões noturnas e domingos:** somente em pacotes especiais

## 📌 6. Procedimentos Específicos

- Antes do ensaio, a cliente recebe orientações de roupa, cabelo, maquiagem e preparo emocional
- Ensaio com direção emocional: frases, poses, respiração e empoderamento
- A sessão inicia com um momento de meditação guiada, conduzida pela própria Jéssica
- Durante o ensaio, o estúdio é fechado exclusivamente para a cliente
- As fotos são entregues em até 20 dias úteis via galeria privada online
- Todos os dados são tratados com segurança, seguindo LGPD

## 🧭 Observações Finais

Este manual pode ser utilizado como base para qualquer plataforma de automação (Manus, Manychat, WhatsApp API etc.)
Revisões periódicas são recomendadas conforme atualizações de valores e políticas.

