# 🔐 CONFIGURAÇÃO DE BACKUP AUTOMÁTICO - GOOGLE DRIVE

## 📋 INSTRUÇÕES PARA AUTORIZAÇÃO

### 🔑 PASSO 1: AUTORIZAR ACESSO AO GOOGLE DRIVE

Para configurar backup automático, você precisa me autorizar acesso ao seu Google Drive. Aqui estão as opções:

#### 🌐 OPÇÃO 1: VIA GOOGLE CLOUD CONSOLE
1. Acesse [Google Cloud Console](https://console.cloud.google.com/)
2. Crie um novo projeto ou use existente
3. Ative a API do Google Drive
4. Crie credenciais de serviço
5. Baixe o arquivo JSON de credenciais
6. Compartilhe as credenciais comigo

#### 📱 OPÇÃO 2: VIA GOOGLE DRIVE API
1. Acesse [Google Developers Console](https://console.developers.google.com/)
2. Crie um projeto
3. Ative Google Drive API
4. Crie credenciais OAuth 2.0
5. Configure domínios autorizados
6. Forneça Client ID e Client Secret

#### 🔧 OPÇÃO 3: VIA APLICATIVO TERCEIRO
1. Use ferramentas como rclone ou gdrive
2. Configure autenticação OAuth
3. Gere token de acesso
4. Compartilhe configuração

### 🛠️ PASSO 2: CONFIGURAR SISTEMA DE BACKUP

Após autorização, vou configurar:

#### 📅 BACKUP AUTOMÁTICO
- **Frequência:** Diário às 00:00
- **Backup incremental:** A cada 4 horas
- **Backup completo:** Semanal aos domingos
- **Retenção:** 30 dias de histórico

#### 📁 ESTRUTURA NO DRIVE
```
Jessica Santos - ERP Fotografia/
├── 📁 Backups-Automaticos/
│   ├── 📁 2024-06-15/
│   │   ├── backup-00h00.tar.gz
│   │   ├── backup-04h00.tar.gz
│   │   ├── backup-08h00.tar.gz
│   │   └── ...
│   └── 📁 Backup-Semanal/
├── 📁 Documentacao/
├── 📁 Codigo-Fonte/
└── 📁 Logs-Backup/
```

#### 🔄 SINCRONIZAÇÃO
- Upload automático de mudanças
- Verificação de integridade
- Logs detalhados de backup
- Notificação de status

### 🔐 PASSO 3: CONFIGURAR CREDENCIAIS

#### 📝 FORMATO DAS CREDENCIAIS
```json
{
  "type": "service_account",
  "project_id": "seu-projeto",
  "private_key_id": "...",
  "private_key": "...",
  "client_email": "...",
  "client_id": "...",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token"
}
```

#### 🛡️ SEGURANÇA
- Credenciais criptografadas
- Acesso apenas para backup
- Logs de auditoria
- Rotação de chaves

## 🚀 SCRIPT DE BACKUP AUTOMÁTICO

### 📄 backup-drive.py
```python
import os
import json
import tarfile
from datetime import datetime
from googleapiclient.discovery import build
from google.oauth2.service_account import Credentials

class BackupDrive:
    def __init__(self, credentials_path):
        self.credentials = Credentials.from_service_account_file(
            credentials_path,
            scopes=['https://www.googleapis.com/auth/drive.file']
        )
        self.service = build('drive', 'v3', credentials=self.credentials)
        self.folder_id = self.get_or_create_folder()
    
    def get_or_create_folder(self):
        # Buscar pasta "Jessica Santos - ERP Fotografia"
        query = "name='Jessica Santos - ERP Fotografia' and mimeType='application/vnd.google-apps.folder'"
        results = self.service.files().list(q=query).execute()
        
        if results['files']:
            return results['files'][0]['id']
        else:
            # Criar pasta
            folder_metadata = {
                'name': 'Jessica Santos - ERP Fotografia',
                'mimeType': 'application/vnd.google-apps.folder'
            }
            folder = self.service.files().create(body=folder_metadata).execute()
            return folder['id']
    
    def create_backup(self):
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_name = f'backup-{timestamp}.tar.gz'
        
        # Criar arquivo de backup
        with tarfile.open(backup_name, 'w:gz') as tar:
            tar.add('/home/ubuntu/jessica-santos-website', 
                   exclude=lambda x: 'node_modules' in x or '.git' in x)
        
        # Upload para Drive
        file_metadata = {
            'name': backup_name,
            'parents': [self.folder_id]
        }
        
        media = MediaFileUpload(backup_name, resumable=True)
        file = self.service.files().create(
            body=file_metadata,
            media_body=media
        ).execute()
        
        # Limpar arquivo local
        os.remove(backup_name)
        
        return file['id']
    
    def schedule_backup(self):
        # Configurar cron job para backup automático
        cron_command = f"0 */4 * * * python3 {__file__}"
        os.system(f'echo "{cron_command}" | crontab -')

if __name__ == "__main__":
    backup = BackupDrive('/path/to/credentials.json')
    backup.create_backup()
```

### ⏰ CRON JOB CONFIGURADO
```bash
# Backup a cada 4 horas
0 */4 * * * /usr/bin/python3 /home/ubuntu/backup-drive.py

# Backup completo diário às 00:00
0 0 * * * /usr/bin/python3 /home/ubuntu/backup-completo.py

# Limpeza de backups antigos (30 dias)
0 2 * * 0 /usr/bin/python3 /home/ubuntu/cleanup-backups.py
```

## 📊 MONITORAMENTO DE BACKUP

### 📈 DASHBOARD DE STATUS
- Status do último backup
- Tamanho dos arquivos
- Tempo de execução
- Erros e alertas
- Próximo backup agendado

### 🔔 NOTIFICAÇÕES
- Email de confirmação de backup
- WhatsApp em caso de erro
- Relatório semanal de status
- Alertas de espaço no Drive

## ⚠️ INSTRUÇÕES IMPORTANTES

### 🔐 PARA AUTORIZAR AGORA:
1. **Escolha uma das opções acima**
2. **Configure as credenciais**
3. **Compartilhe comigo as informações**
4. **Teste o primeiro backup**
5. **Ative monitoramento**

### 📋 CHECKLIST DE AUTORIZAÇÃO:
- [ ] Projeto Google Cloud criado
- [ ] API Google Drive ativada
- [ ] Credenciais de serviço geradas
- [ ] Arquivo JSON baixado
- [ ] Permissões configuradas
- [ ] Teste de acesso realizado

### 🚨 SEGURANÇA:
- Credenciais apenas para backup
- Acesso limitado à pasta específica
- Criptografia de dados sensíveis
- Logs de auditoria ativados
- Rotação de chaves programada

---

**🎯 RESULTADO:** Após autorização, teremos backup automático funcionando 24/7, garantindo que nunca mais perderemos trabalho!

