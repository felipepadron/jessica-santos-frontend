import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { 
  Shield, 
  User, 
  Lock, 
  Eye, 
  EyeOff, 
  LogIn,
  AlertTriangle,
  Check
} from 'lucide-react'

const Login = ({ onLogin }) => {
  const [credentials, setCredentials] = useState({
    usuario: '',
    senha: ''
  })
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  // Verificar se já está logado
  useEffect(() => {
    const isLoggedIn = localStorage.getItem('jessica_admin_logged')
    const loginTime = localStorage.getItem('jessica_admin_login_time')
    
    if (isLoggedIn && loginTime) {
      const now = new Date().getTime()
      const loginTimestamp = parseInt(loginTime)
      const hoursPassed = (now - loginTimestamp) / (1000 * 60 * 60)
      
      // Sessão expira em 24 horas
      if (hoursPassed < 24) {
        onLogin(true)
      } else {
        localStorage.removeItem('jessica_admin_logged')
        localStorage.removeItem('jessica_admin_login_time')
      }
    }
  }, [onLogin])

  const handleLogin = async () => {
    setLoading(true)
    setError('')

    try {
      // Simular delay de autenticação
      await new Promise(resolve => setTimeout(resolve, 1000))

      // Verificar credenciais (em produção seria via API)
      const validCredentials = [
        { usuario: 'jessica', senha: 'admin123' },
        { usuario: 'admin', senha: 'jessica2024' },
        { usuario: 'jessicasantos', senha: 'foto123' }
      ]

      const isValid = validCredentials.some(
        cred => cred.usuario === credentials.usuario && cred.senha === credentials.senha
      )

      if (isValid) {
        // Salvar login
        localStorage.setItem('jessica_admin_logged', 'true')
        localStorage.setItem('jessica_admin_login_time', new Date().getTime().toString())
        localStorage.setItem('jessica_admin_user', credentials.usuario)
        
        // Log de acesso
        const accessLog = JSON.parse(localStorage.getItem('jessica_access_log') || '[]')
        accessLog.push({
          usuario: credentials.usuario,
          timestamp: new Date().toISOString(),
          ip: 'localhost', // Em produção seria o IP real
          userAgent: navigator.userAgent
        })
        localStorage.setItem('jessica_access_log', JSON.stringify(accessLog.slice(-50))) // Manter últimos 50 logs

        onLogin(true)
      } else {
        setError('Usuário ou senha incorretos')
      }
    } catch (err) {
      setError('Erro ao fazer login. Tente novamente.')
    } finally {
      setLoading(false)
    }
  }

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleLogin()
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-rose-50 to-pink-100 px-4">
      <div className="w-full max-w-md">
        {/* Logo/Header */}
        <div className="text-center mb-8">
          <div className="mx-auto w-16 h-16 bg-rose-600 rounded-full flex items-center justify-center mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">
            Jéssica Santos Fotografia
          </h1>
          <p className="text-gray-600 mt-2">
            Painel Administrativo
          </p>
        </div>

        {/* Card de Login */}
        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center space-x-2">
              <LogIn className="w-5 h-5" />
              <span>Login Administrativo</span>
            </CardTitle>
            <CardDescription>
              Entre com suas credenciais para acessar o painel
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {/* Erro */}
            {error && (
              <Alert variant="destructive">
                <AlertTriangle className="w-4 h-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Formulário */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="usuario">Usuário</Label>
                <div className="relative mt-2">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="usuario"
                    type="text"
                    value={credentials.usuario}
                    onChange={(e) => setCredentials({
                      ...credentials,
                      usuario: e.target.value
                    })}
                    onKeyPress={handleKeyPress}
                    placeholder="Digite seu usuário"
                    className="pl-10"
                    disabled={loading}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="senha">Senha</Label>
                <div className="relative mt-2">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="senha"
                    type={showPassword ? 'text' : 'password'}
                    value={credentials.senha}
                    onChange={(e) => setCredentials({
                      ...credentials,
                      senha: e.target.value
                    })}
                    onKeyPress={handleKeyPress}
                    placeholder="Digite sua senha"
                    className="pl-10 pr-10"
                    disabled={loading}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Botão de Login */}
            <Button 
              onClick={handleLogin}
              disabled={loading || !credentials.usuario || !credentials.senha}
              className="w-full bg-rose-600 hover:bg-rose-700"
            >
              {loading ? (
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Entrando...</span>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <LogIn className="w-4 h-4" />
                  <span>Entrar</span>
                </div>
              )}
            </Button>

            {/* Informações de Acesso */}
            <div className="text-center">
              <p className="text-sm text-gray-500 mb-4">
                Credenciais de demonstração:
              </p>
              <div className="space-y-2">
                <Badge variant="outline" className="text-xs">
                  jessica / admin123
                </Badge>
                <br />
                <Badge variant="outline" className="text-xs">
                  admin / jessica2024
                </Badge>
              </div>
            </div>

            {/* Recursos de Segurança */}
            <div className="text-center pt-4 border-t">
              <div className="flex items-center justify-center space-x-4 text-xs text-gray-500">
                <div className="flex items-center space-x-1">
                  <Shield className="w-3 h-3" />
                  <span>Sessão segura</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Check className="w-3 h-3" />
                  <span>Logs de acesso</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-8 text-sm text-gray-500">
          <p>© 2024 Jéssica Santos Fotografia</p>
          <p>Sistema desenvolvido com segurança</p>
        </div>
      </div>
    </div>
  )
}

export default Login

