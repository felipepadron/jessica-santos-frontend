import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Menu, X, Calendar, Phone, Instagram, Mail, Settings, User } from 'lucide-react'

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false)

  const toggleMenu = () => {
    setIsOpen(!isOpen)
  }

  return (
    <>
      {/* Navbar Desktop e Mobile */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-amber-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-amber-600 to-amber-700 rounded-full flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-lg">JS</span>
              </div>
              <div className="hidden sm:block">
                <span className="font-serif font-semibold text-xl text-amber-800">
                  Jéssica Santos
                </span>
                <p className="text-xs text-amber-600 -mt-1">Fotografia</p>
              </div>
            </Link>

            {/* Desktop Navigation - Botões Coloridos */}
            <div className="hidden lg:flex items-center space-x-2">
              <Link to="/" className="nav-pill-inicio">
                Início
              </Link>
              <Link to="/sobre" className="nav-pill-sobre">
                Sobre
              </Link>
              <Link to="/galeria" className="nav-pill-portfolio">
                Portfólio
              </Link>
              <Link to="/servicos" className="nav-pill-servicos">
                Serviços
              </Link>
              <Link to="/contato" className="nav-pill-contato">
                Contato
              </Link>
            </div>

            {/* Desktop Actions */}
            <div className="hidden lg:flex items-center space-x-3">
              {/* Acesso Admin Discreto */}
              <Link 
                to="/login" 
                className="p-2 text-amber-600 hover:text-amber-800 hover:bg-amber-50 rounded-lg transition-all"
                title="Painel Administrativo"
              >
                <Settings className="w-5 h-5" />
              </Link>
              
              {/* CTA Principal */}
              <Link to="/agendamento" className="btn-cta-primary">
                <Calendar className="w-4 h-4" />
                Agendar Sessão
              </Link>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={toggleMenu}
              className="lg:hidden p-2 rounded-xl bg-amber-50 hover:bg-amber-100 transition-colors"
            >
              {isOpen ? <X className="w-6 h-6 text-amber-800" /> : <Menu className="w-6 h-6 text-amber-800" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation - Botões Coloridos Visíveis */}
        {isOpen && (
          <div className="lg:hidden bg-white/98 backdrop-blur-md border-t border-amber-100">
            <div className="px-4 py-6 space-y-4">
              {/* Navegação Mobile com Botões Coloridos */}
              <div className="grid grid-cols-2 gap-3">
                <Link 
                  to="/" 
                  className="nav-pill-mobile-inicio"
                  onClick={() => setIsOpen(false)}
                >
                  🏠 Início
                </Link>
                <Link 
                  to="/sobre" 
                  className="nav-pill-mobile-sobre"
                  onClick={() => setIsOpen(false)}
                >
                  👩‍💼 Sobre
                </Link>
                <Link 
                  to="/galeria" 
                  className="nav-pill-mobile-portfolio"
                  onClick={() => setIsOpen(false)}
                >
                  📸 Portfólio
                </Link>
                <Link 
                  to="/servicos" 
                  className="nav-pill-mobile-servicos"
                  onClick={() => setIsOpen(false)}
                >
                  💎 Serviços
                </Link>
              </div>
              
              {/* Botões de Ação Mobile */}
              <div className="space-y-3 pt-4 border-t border-amber-100">
                <Link 
                  to="/agendamento" 
                  className="btn-cta-mobile"
                  onClick={() => setIsOpen(false)}
                >
                  <Calendar className="w-5 h-5" />
                  Agendar Sessão
                </Link>
                <Link 
                  to="/contato" 
                  className="btn-secondary-mobile"
                  onClick={() => setIsOpen(false)}
                >
                  <Mail className="w-5 h-5" />
                  Entrar em Contato
                </Link>
              </div>

              {/* Acessos Administrativos Mobile */}
              <div className="pt-4 border-t border-amber-100">
                <p className="text-sm font-medium text-amber-700 mb-3">Área Restrita</p>
                <div className="grid grid-cols-2 gap-3">
                  <Link 
                    to="/login" 
                    className="flex items-center justify-center gap-2 p-3 bg-amber-100 text-amber-800 rounded-xl font-medium text-sm hover:bg-amber-200 transition-colors"
                    onClick={() => setIsOpen(false)}
                  >
                    <Settings className="w-4 h-4" />
                    Admin
                  </Link>
                  <Link 
                    to="/area-cliente" 
                    className="flex items-center justify-center gap-2 p-3 bg-blue-100 text-blue-800 rounded-xl font-medium text-sm hover:bg-blue-200 transition-colors"
                    onClick={() => setIsOpen(false)}
                  >
                    <User className="w-4 h-4" />
                    Cliente
                  </Link>
                </div>
              </div>

              {/* Redes Sociais Mobile */}
              <div className="flex justify-center space-x-4 pt-4 border-t border-amber-100">
                <a href="https://instagram.com/jessicasantosfotografia" className="social-icon">
                  <Instagram className="w-5 h-5" />
                </a>
                <a href="tel:+5511999999999" className="social-icon">
                  <Phone className="w-5 h-5" />
                </a>
                <a href="mailto:contato@jessicasantos.com" className="social-icon">
                  <Mail className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Spacer para compensar navbar fixa */}
      <div className="h-16"></div>
    </>
  )
}

export default Navbar

