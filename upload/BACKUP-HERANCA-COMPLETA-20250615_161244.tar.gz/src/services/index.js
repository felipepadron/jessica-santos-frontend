// Serviços prontos para uso imediato
import integrationConfig from '../config/integrations.js'

// Serviço de WhatsApp
export class WhatsAppService {
  constructor() {
    this.config = integrationConfig.whatsapp
  }
  
  async enviarMensagem(numero, mensagem) {
    if (!this.config.accessToken) {
      console.warn('WhatsApp não configurado')
      return { success: false, error: 'Token não configurado' }
    }
    
    try {
      const response = await fetch(`${this.config.baseUrl}/${this.config.phoneNumberId}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.config.accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: numero.replace(/\D/g, ''), // Remove formatação
          type: 'text',
          text: { body: mensagem }
        })
      })
      
      const result = await response.json()
      return { success: true, data: result }
    } catch (error) {
      console.error('Erro WhatsApp:', error)
      return { success: false, error: error.message }
    }
  }
  
  async confirmarAgendamento(cliente, agendamento) {
    const mensagem = this.config.templates.confirmacaoAgendamento(cliente, agendamento)
    return await this.enviarMensagem(cliente.telefone, mensagem)
  }
  
  async enviarLembrete(cliente, agendamento) {
    const mensagem = this.config.templates.lembrete24h(cliente, agendamento)
    return await this.enviarMensagem(cliente.telefone, mensagem)
  }
  
  async notificarEntrega(cliente, galeria) {
    const mensagem = this.config.templates.entregaFotos(cliente, galeria)
    return await this.enviarMensagem(cliente.telefone, mensagem)
  }
}

// Serviço de Email
export class EmailService {
  constructor() {
    this.config = integrationConfig.email
  }
  
  async enviarEmail(para, assunto, html) {
    try {
      // Em produção, usar nodemailer ou serviço de email
      // Por enquanto, simular envio
      console.log('Email enviado:', { para, assunto })
      return { success: true }
    } catch (error) {
      console.error('Erro Email:', error)
      return { success: false, error: error.message }
    }
  }
  
  async confirmarAgendamento(cliente, agendamento) {
    const template = this.config.templates.confirmacaoAgendamento(cliente, agendamento)
    return await this.enviarEmail(cliente.email, template.subject, template.html)
  }
  
  async enviarLembrete(cliente, agendamento) {
    const template = this.config.templates.lembreteEnsaio(cliente, agendamento)
    return await this.enviarEmail(cliente.email, template.subject, template.html)
  }
}

// Serviço de Analytics
export class AnalyticsService {
  constructor() {
    this.config = integrationConfig.analytics
    this.initialized = false
    this.init()
  }
  
  init() {
    if (typeof window !== 'undefined' && this.config.measurementId) {
      // Carregar Google Analytics
      const script = document.createElement('script')
      script.src = `https://www.googletagmanager.com/gtag/js?id=${this.config.measurementId}`
      document.head.appendChild(script)
      
      window.dataLayer = window.dataLayer || []
      window.gtag = function() { window.dataLayer.push(arguments) }
      window.gtag('js', new Date())
      window.gtag('config', this.config.measurementId)
      
      this.initialized = true
    }
  }
  
  trackEvent(eventName, parameters = {}) {
    if (this.initialized && window.gtag) {
      window.gtag('event', eventName, parameters)
    }
  }
  
  trackAgendamento(servico, valor) {
    const event = this.config.events.agendamento(servico, valor)
    this.trackEvent(event.event_name, {
      event_category: event.event_category,
      event_label: event.event_label,
      value: event.value,
      currency: event.currency
    })
  }
  
  trackCalculadoraUso(servico) {
    const event = this.config.events.calculadoraUso(servico)
    this.trackEvent(event.event_name, {
      event_category: event.event_category,
      event_label: event.event_label
    })
  }
  
  trackWhatsAppClick() {
    const event = this.config.events.whatsappClick()
    this.trackEvent(event.event_name, {
      event_category: event.event_category,
      event_label: event.event_label
    })
  }
}

// Serviço de Pagamentos
export class PaymentService {
  constructor() {
    this.config = integrationConfig.stripe
  }
  
  async createPaymentIntent(amount, currency = 'brl') {
    try {
      const response = await fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount, currency })
      })
      
      return await response.json()
    } catch (error) {
      console.error('Erro Payment Intent:', error)
      throw error
    }
  }
  
  async processPayment(paymentMethodId, amount) {
    try {
      const stripe = await loadStripe(this.config.publishableKey)
      
      const { error, paymentIntent } = await stripe.confirmCardPayment(paymentMethodId)
      
      if (error) {
        return { success: false, error: error.message }
      }
      
      return { success: true, paymentIntent }
    } catch (error) {
      console.error('Erro Payment:', error)
      return { success: false, error: error.message }
    }
  }
}

// Serviço de Backup
export class BackupService {
  constructor() {
    this.enabled = process.env.BACKUP_ENABLED === 'true'
  }
  
  async criarBackup() {
    if (!this.enabled) return { success: false, message: 'Backup desabilitado' }
    
    try {
      const dados = {
        timestamp: new Date().toISOString(),
        clientes: this.getLocalStorageData('jessica_erp_clientes'),
        agendamentos: this.getLocalStorageData('jessica_erp_agendamentos'),
        pagamentos: this.getLocalStorageData('jessica_erp_pagamentos'),
        configuracoes: this.getLocalStorageData('jessica_erp_config')
      }
      
      // Salvar no localStorage como backup local
      localStorage.setItem('jessica_erp_backup_latest', JSON.stringify(dados))
      
      // Em produção, enviar para Google Drive
      console.log('Backup criado:', dados.timestamp)
      
      return { success: true, timestamp: dados.timestamp }
    } catch (error) {
      console.error('Erro Backup:', error)
      return { success: false, error: error.message }
    }
  }
  
  getLocalStorageData(key) {
    try {
      return JSON.parse(localStorage.getItem(key) || '[]')
    } catch {
      return []
    }
  }
  
  async restaurarBackup(backupData) {
    try {
      if (backupData.clientes) {
        localStorage.setItem('jessica_erp_clientes', JSON.stringify(backupData.clientes))
      }
      if (backupData.agendamentos) {
        localStorage.setItem('jessica_erp_agendamentos', JSON.stringify(backupData.agendamentos))
      }
      if (backupData.pagamentos) {
        localStorage.setItem('jessica_erp_pagamentos', JSON.stringify(backupData.pagamentos))
      }
      if (backupData.configuracoes) {
        localStorage.setItem('jessica_erp_config', JSON.stringify(backupData.configuracoes))
      }
      
      return { success: true }
    } catch (error) {
      console.error('Erro Restore:', error)
      return { success: false, error: error.message }
    }
  }
}

// Instâncias globais dos serviços
export const whatsappService = new WhatsAppService()
export const emailService = new EmailService()
export const analyticsService = new AnalyticsService()
export const paymentService = new PaymentService()
export const backupService = new BackupService()

// Hook para usar os serviços
export const useServices = () => {
  return {
    whatsapp: whatsappService,
    email: emailService,
    analytics: analyticsService,
    payment: paymentService,
    backup: backupService
  }
}

