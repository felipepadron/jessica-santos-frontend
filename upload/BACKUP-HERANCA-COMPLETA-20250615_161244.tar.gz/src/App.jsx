import React, { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { ConfigProvider } from './contexts/ConfigContext'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import AccessButton from './components/AccessButton'
import Login from './components/Login'
import Home from './pages/Home'
import Servicos from './pages/Servicos'
import Agendamento from './pages/Agendamento'
import Galeria from './pages/Galeria'
import Sobre from './pages/Sobre'
import Contato from './pages/Contato'
import Dashboard from './pages/Dashboard'
import ConfiguracaoSistema from './pages/ConfiguracaoSistema'
import AreaCliente from './pages/AreaCliente'
import './App.css'

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  // Verificar se está logado
  React.useEffect(() => {
    const isLoggedIn = localStorage.getItem('jessica_admin_logged')
    const loginTime = localStorage.getItem('jessica_admin_login_time')
    
    if (isLoggedIn && loginTime) {
      const now = new Date().getTime()
      const loginTimestamp = parseInt(loginTime)
      const hoursPassed = (now - loginTimestamp) / (1000 * 60 * 60)
      
      if (hoursPassed < 24) {
        setIsAuthenticated(true)
      } else {
        localStorage.removeItem('jessica_admin_logged')
        localStorage.removeItem('jessica_admin_login_time')
      }
    }
  }, [])

  // Componente para rotas protegidas
  const ProtectedRoute = ({ children }) => {
    return isAuthenticated ? children : <Navigate to="/login" />
  }

  // Componente para rotas públicas quando logado
  const PublicRoute = ({ children }) => {
    return !isAuthenticated ? children : <Navigate to="/dashboard" />
  }

  return (
    <ConfigProvider>
      <Router>
        <div className="App">
          <Routes>
            {/* Rota de Login */}
            <Route 
              path="/login" 
              element={
                <PublicRoute>
                  <Login onLogin={setIsAuthenticated} />
                </PublicRoute>
              } 
            />

            {/* Rotas Administrativas Protegidas */}
            <Route 
              path="/dashboard" 
              element={
                <ProtectedRoute>
                  <Navbar />
                  <Dashboard />
                  <Footer />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/configuracao-sistema" 
              element={
                <ProtectedRoute>
                  <Navbar />
                  <ConfiguracaoSistema />
                  <Footer />
                </ProtectedRoute>
              } 
            />

            {/* Área do Cliente */}
            <Route 
              path="/area-cliente" 
              element={<AreaCliente />} 
            />

            {/* Rotas Públicas */}
            <Route 
              path="/" 
              element={
                <>
                  <Navbar />
                  <Home />
                  <Footer />
                  <AccessButton />
                </>
              } 
            />
            <Route 
              path="/servicos" 
              element={
                <>
                  <Navbar />
                  <Servicos />
                  <Footer />
                  <AccessButton />
                </>
              } 
            />
            <Route 
              path="/agendamento" 
              element={
                <>
                  <Navbar />
                  <Agendamento />
                  <Footer />
                  <AccessButton />
                </>
              } 
            />
            <Route 
              path="/galeria" 
              element={
                <>
                  <Navbar />
                  <Galeria />
                  <Footer />
                  <AccessButton />
                </>
              } 
            />
            <Route 
              path="/sobre" 
              element={
                <>
                  <Navbar />
                  <Sobre />
                  <Footer />
                  <AccessButton />
                </>
              } 
            />
            <Route 
              path="/contato" 
              element={
                <>
                  <Navbar />
                  <Contato />
                  <Footer />
                  <AccessButton />
                </>
              } 
            />

            {/* Rota padrão */}
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </div>
      </Router>
    </ConfigProvider>
  )
}

export default App

