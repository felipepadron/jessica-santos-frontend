import React from 'react'
import { Calendar, Instagram, Star, Users, Camera, Heart, ArrowRight, Sparkles, Award, Clock } from 'lucide-react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-pink-50">
      {/* Hero Section Mobile-First Renovado */}
      <section className="relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 bg-gradient-to-br from-amber-100/30 via-orange-100/20 to-pink-100/30"></div>
        <div className="absolute inset-0 opacity-40" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23f59e0b' fill-opacity='0.05'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        
        <div className="relative max-w-4xl mx-auto px-4 py-12 md:py-20">
          {/* Badge Especialização Renovado */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500/10 to-orange-500/10 backdrop-blur-sm border border-amber-300/30 rounded-full text-sm font-medium text-amber-800 mb-8 shadow-lg">
            <div className="w-2 h-2 bg-amber-500 rounded-full animate-pulse"></div>
            <Camera className="w-4 h-4" />
            Fotógrafa Especializada em Retratos Femininos
            <Sparkles className="w-4 h-4" />
          </div>

          {/* Título Principal Renovado */}
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-gray-800 mb-4 leading-tight">
              <span className="bg-gradient-to-r from-amber-600 via-orange-600 to-pink-600 bg-clip-text text-transparent">
                Jéssica Santos
              </span>
            </h1>
            
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-serif text-amber-700 mb-6 opacity-90">
              Fotografia
            </h2>

            {/* Descrição Renovada */}
            <p className="text-lg md:text-xl text-gray-700 max-w-2xl mx-auto leading-relaxed mb-8">
              Eternizando momentos únicos da maternidade e família com 
              <span className="font-semibold text-amber-700"> sensibilidade</span>, 
              <span className="font-semibold text-orange-700"> técnica</span> e 
              <span className="font-semibold text-pink-700"> muito amor</span>. 
              Cada foto conta uma história especial.
            </p>
          </div>

          {/* Botões de Ação Renovados */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link 
              to="/agendamento" 
              className="group inline-flex items-center justify-center gap-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white px-8 py-4 rounded-2xl font-semibold text-lg transition-all duration-300 hover:-translate-y-1 shadow-xl hover:shadow-2xl"
            >
              <Calendar className="w-5 h-5 group-hover:scale-110 transition-transform" />
              Agendar Ensaio
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link 
              to="/galeria" 
              className="group inline-flex items-center justify-center gap-3 bg-white/80 backdrop-blur-sm hover:bg-white text-amber-700 px-8 py-4 rounded-2xl font-semibold text-lg transition-all duration-300 hover:-translate-y-1 shadow-lg hover:shadow-xl border border-amber-200"
            >
              <Instagram className="w-5 h-5 group-hover:scale-110 transition-transform" />
              Ver Portfolio
            </Link>
          </div>

          {/* Métricas de Credibilidade Renovadas */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-2xl mx-auto">
            <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 text-center shadow-lg border border-white/20">
              <div className="flex items-center justify-center mb-2">
                <Star className="w-6 h-6 text-yellow-500 fill-current" />
                <span className="text-3xl font-bold text-gray-800 ml-2">4.9</span>
                <span className="text-lg text-gray-600">/5</span>
              </div>
              <p className="text-sm text-gray-600 font-medium">127 avaliações</p>
            </div>
            
            <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 text-center shadow-lg border border-white/20">
              <div className="flex items-center justify-center mb-2">
                <Heart className="w-6 h-6 text-pink-500 fill-current" />
                <span className="text-3xl font-bold text-gray-800 ml-2">+500</span>
              </div>
              <p className="text-sm text-gray-600 font-medium">famílias atendidas</p>
            </div>
            
            <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 text-center shadow-lg border border-white/20">
              <div className="flex items-center justify-center mb-2">
                <Award className="w-6 h-6 text-amber-500 fill-current" />
                <span className="text-3xl font-bold text-gray-800 ml-2">8</span>
              </div>
              <p className="text-sm text-gray-600 font-medium">anos de experiência</p>
            </div>
          </div>
        </div>
      </section>

      {/* Seção de Serviços Renovada */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500/10 to-orange-500/10 rounded-full text-sm font-medium text-amber-800 mb-4">
              <Sparkles className="w-4 h-4" />
              Nossos Serviços
            </div>
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-gray-800 mb-4">
              Especializações em Fotografia
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Cada momento da sua vida merece ser eternizado com carinho e profissionalismo. 
              Conheça nossos serviços especializados.
            </p>
          </div>

          {/* Grid de Serviços Renovado */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Ensaio Gestante */}
            <div className="group bg-white rounded-3xl p-6 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 border border-pink-100 hover:border-pink-200">
              <div className="flex items-center justify-between mb-4">
                <div className="w-14 h-14 bg-gradient-to-br from-pink-500 to-rose-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <Heart className="w-7 h-7 text-white" />
                </div>
                <span className="bg-gradient-to-r from-pink-500 to-rose-600 text-white px-3 py-1 rounded-full text-xs font-bold shadow-md">
                  ⭐ Mais Procurado
                </span>
              </div>
              <h3 className="text-xl font-serif font-bold text-gray-800 mb-2">
                Ensaio Gestante
              </h3>
              <p className="text-3xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent mb-3">
                R$ 450
              </p>
              <p className="text-gray-600 text-sm mb-6 leading-relaxed">
                Eternize a beleza da maternidade com fotos únicas e emocionantes
              </p>
              <Link to="/servicos" className="group/link inline-flex items-center text-pink-600 font-semibold hover:text-pink-700 transition-colors">
                Saiba Mais 
                <ArrowRight className="w-4 h-4 ml-1 group-hover/link:translate-x-1 transition-transform" />
              </Link>
            </div>

            {/* Newborn */}
            <div className="group bg-white rounded-3xl p-6 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 border border-blue-100 hover:border-blue-200">
              <div className="flex items-center justify-between mb-4">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <Users className="w-7 h-7 text-white" />
                </div>
                <span className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-3 py-1 rounded-full text-xs font-bold shadow-md">
                  ⭐ Mais Procurado
                </span>
              </div>
              <h3 className="text-xl font-serif font-bold text-gray-800 mb-2">
                Newborn
              </h3>
              <p className="text-3xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent mb-3">
                R$ 550
              </p>
              <p className="text-gray-600 text-sm mb-6 leading-relaxed">
                Primeiros dias de vida capturados com todo carinho e delicadeza
              </p>
              <Link to="/servicos" className="group/link inline-flex items-center text-blue-600 font-semibold hover:text-blue-700 transition-colors">
                Saiba Mais 
                <ArrowRight className="w-4 h-4 ml-1 group-hover/link:translate-x-1 transition-transform" />
              </Link>
            </div>

            {/* Ensaio Família */}
            <div className="group bg-white rounded-3xl p-6 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 border border-green-100 hover:border-green-200">
              <div className="flex items-center justify-between mb-4">
                <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <Users className="w-7 h-7 text-white" />
                </div>
              </div>
              <h3 className="text-xl font-serif font-bold text-gray-800 mb-2">
                Ensaio Família
              </h3>
              <p className="text-3xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent mb-3">
                R$ 380
              </p>
              <p className="text-gray-600 text-sm mb-6 leading-relaxed">
                Momentos especiais em família registrados para sempre
              </p>
              <Link to="/servicos" className="group/link inline-flex items-center text-green-600 font-semibold hover:text-green-700 transition-colors">
                Saiba Mais 
                <ArrowRight className="w-4 h-4 ml-1 group-hover/link:translate-x-1 transition-transform" />
              </Link>
            </div>

            {/* Mentoria */}
            <div className="group bg-white rounded-3xl p-6 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 border border-purple-100 hover:border-purple-200">
              <div className="flex items-center justify-between mb-4">
                <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <Camera className="w-7 h-7 text-white" />
                </div>
              </div>
              <h3 className="text-xl font-serif font-bold text-gray-800 mb-2">
                Mentoria Fotográfica
              </h3>
              <p className="text-3xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent mb-3">
                R$ 200
              </p>
              <p className="text-gray-600 text-sm mb-6 leading-relaxed">
                Aprenda técnicas profissionais de fotografia
              </p>
              <Link to="/servicos" className="group/link inline-flex items-center text-purple-600 font-semibold hover:text-purple-700 transition-colors">
                Saiba Mais 
                <ArrowRight className="w-4 h-4 ml-1 group-hover/link:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>

          {/* CTA Central Renovado */}
          <div className="text-center mt-12">
            <Link 
              to="/agendamento" 
              className="group inline-flex items-center justify-center gap-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white px-10 py-5 rounded-2xl font-bold text-lg transition-all duration-300 hover:-translate-y-1 shadow-xl hover:shadow-2xl"
            >
              <Calendar className="w-6 h-6 group-hover:scale-110 transition-transform" />
              Agendar Minha Sessão
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </section>

      {/* Seção de Depoimentos Renovada */}
      <section className="py-16 px-4 bg-white/50 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500/10 to-orange-500/10 rounded-full text-sm font-medium text-amber-800 mb-4">
              <Star className="w-4 h-4 fill-current text-yellow-500" />
              Depoimentos
            </div>
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-gray-800 mb-4">
              O que dizem nossas clientes
            </h2>
            <p className="text-lg text-gray-600">
              A satisfação das famílias é nossa maior recompensa
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Depoimento 1 */}
            <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-3xl p-8 shadow-xl border border-amber-100 hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
              <div className="flex items-center mb-6">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
              </div>
              <p className="text-gray-700 italic mb-6 text-lg leading-relaxed">
                "Jéssica é incrível! Captou cada momento especial da minha gestação com tanto carinho."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-rose-600 rounded-full flex items-center justify-center text-white font-bold text-lg mr-4">
                  A
                </div>
                <div>
                  <div className="font-bold text-gray-800">Ana Carolina</div>
                  <div className="text-sm text-gray-600">Ensaio Gestante</div>
                </div>
              </div>
            </div>

            {/* Depoimento 2 */}
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-3xl p-8 shadow-xl border border-blue-100 hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
              <div className="flex items-center mb-6">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
              </div>
              <p className="text-gray-700 italic mb-6 text-lg leading-relaxed">
                "O ensaio newborn do meu bebê ficou perfeito. Profissional excepcional!"
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-lg mr-4">
                  M
                </div>
                <div>
                  <div className="font-bold text-gray-800">Mariana Silva</div>
                  <div className="text-sm text-gray-600">Newborn</div>
                </div>
              </div>
            </div>

            {/* Depoimento 3 */}
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-3xl p-8 shadow-xl border border-green-100 hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
              <div className="flex items-center mb-6">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
              </div>
              <p className="text-gray-700 italic mb-6 text-lg leading-relaxed">
                "Fotos lindas da nossa família. Jéssica tem um olhar único para capturar emoções."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center text-white font-bold text-lg mr-4">
                  O
                </div>
                <div>
                  <div className="font-bold text-gray-800">Família Oliveira</div>
                  <div className="text-sm text-gray-600">Ensaio Família</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Final Renovado */}
      <section className="py-20 px-4 bg-gradient-to-br from-amber-600 via-orange-600 to-pink-600 text-white relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-40" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        
        <div className="relative max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-sm font-medium mb-6">
            <Clock className="w-4 h-4" />
            Vagas Limitadas
          </div>
          
          <h2 className="text-3xl md:text-5xl font-serif font-bold mb-6 leading-tight">
            Pronta para eternizar seus momentos especiais?
          </h2>
          <p className="text-xl md:text-2xl mb-10 opacity-90 leading-relaxed">
            Entre em contato e vamos conversar sobre como posso capturar seus momentos únicos
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <a 
              href="https://wa.me/5511999999999" 
              className="group inline-flex items-center justify-center gap-3 bg-green-500 hover:bg-green-600 text-white px-10 py-5 rounded-2xl font-bold text-lg transition-all duration-300 hover:-translate-y-1 shadow-2xl hover:shadow-green-500/25"
            >
              <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center">
                📱
              </div>
              WhatsApp
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </a>
            <Link 
              to="/agendamento" 
              className="group inline-flex items-center justify-center gap-3 bg-white hover:bg-gray-50 text-amber-600 px-10 py-5 rounded-2xl font-bold text-lg transition-all duration-300 hover:-translate-y-1 shadow-2xl"
            >
              <Calendar className="w-6 h-6 group-hover:scale-110 transition-transform" />
              Agendar Conversa
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home

